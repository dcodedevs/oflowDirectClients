<?php

if(!function_exists("fw_get_notifications")) include(__DIR__."/includes/fnc_fw_get_notifications.php");
if(!function_exists("fw_set_notifications_seen")) include(__DIR__."/includes/fnc_fw_set_notifications_seen.php");
if(!function_exists("fw_set_notification_pressed")) include(__DIR__."/includes/fnc_fw_set_notification_pressed.php");

?>
