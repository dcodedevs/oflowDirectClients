<?php
$sys_table_indexes = array('creditor_id:key:creditor_invoice_payment:creditor_id', 'invoice_number:key:creditor_invoice_payment:invoice_number');
?>