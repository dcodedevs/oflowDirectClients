<?php
$sys_table_indexes = array('creditor_id:key:creditor_syncing_log:creditor_id', 'creditor_syncing_id:key:creditor_syncing_log:creditor_syncing_id', 'type:key:creditor_syncing_log:type');
?>