<?php
$sys_table_indexes = array('creditor_id:key:creditor_additional_bookaccounts:creditor_id');
?>