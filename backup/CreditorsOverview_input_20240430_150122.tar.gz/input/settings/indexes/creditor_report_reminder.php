<?php
$sys_table_indexes = array('date_and_id:key:creditor_report_reminder:creditor_id,date');
?>