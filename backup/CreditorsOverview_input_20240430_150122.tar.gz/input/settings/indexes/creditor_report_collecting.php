<?php
$sys_table_indexes = array('creditor_id:key:creditor_report_collecting:creditor_id');
?>