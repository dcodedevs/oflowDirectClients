<?php
$sys_table_indexes = array('reminder_process_id:key:creditor_reminder_custom_profiles:reminder_process_id', 'creditor_id:key:creditor_reminder_custom_profiles:creditor_id');
?>