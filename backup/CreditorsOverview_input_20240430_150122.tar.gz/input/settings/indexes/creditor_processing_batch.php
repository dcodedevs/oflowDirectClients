<?php
$sys_table_indexes = array('creditor_id:key:creditor_processing_batch:creditor_id');
?>