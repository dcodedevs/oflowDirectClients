<?php
$sys_table_indexes = array('creditor_id:key:creditor_syncing:creditor_id');
?>