<?php
$sys_table_indexes = array('collecting_case_id:key:creditor_invoice:collecting_case_id', 'creditor_id:key:creditor_invoice:creditor_id', 'debitor_id:key:creditor_invoice:debitor_id', 'reminder_process_id:key:creditor_invoice:reminder_process_id', 'collecting_process_id:key:creditor_invoice:collecting_process_id');
?>