<?php
$sys_table_indexes = array('transaction_id:key:creditor_processing_batch_line:transaction_id', 'creditor_processing_batch_id:key:creditor_processing_batch_line:creditor_processing_batch_id');
?>