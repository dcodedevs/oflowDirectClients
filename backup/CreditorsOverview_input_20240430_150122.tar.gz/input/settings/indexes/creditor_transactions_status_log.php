<?php
$sys_table_indexes = array('creditor_transaction_id:key:creditor_transactions_status_log:creditor_transaction_id', 'creditor_id:key:creditor_transactions_status_log:creditor_id', 'tab_status_from:key:creditor_transactions_status_log:tab_status_from', 'tab_status_to:key:creditor_transactions_status_log:tab_status_to', 'source:key:creditor_transactions_status_log:source');
?>