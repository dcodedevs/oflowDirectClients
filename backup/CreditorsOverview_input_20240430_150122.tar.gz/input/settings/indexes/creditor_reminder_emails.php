<?php
$sys_table_indexes = array('creditor_id:key:creditor_reminder_emails:creditor_id');
?>