<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'customer_id' => 1,
  'sync_from_accounting' => 1,
  'integration_module' => 1,
  'entity_id' => 1,
  'lastImportedDate' => 1,
  'create_cases' => 1,
  'days_overdue_startcase' => 1,
  'process_for_handling_cases' => 1,
  'process_for_suggested_cases' => 1,
  'last_process_date' => 1,
);
?>