<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:creditor:0:0:CreditorsOverview:¤";
?>