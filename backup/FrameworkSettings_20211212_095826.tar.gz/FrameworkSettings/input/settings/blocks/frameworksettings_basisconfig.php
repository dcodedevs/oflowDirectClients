<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'showContactList' => 1,
  'show_brand_logo' => 1,
  'brand_logo_in_elements_global' => 1,
  'activate_channel_admin' => 1,
  'activateHelpButton' => 1,
  'helpArticle' => 1,
  'activateReadIntroNewUsers' => 1,
  'introArticle' => 1,
);
?>