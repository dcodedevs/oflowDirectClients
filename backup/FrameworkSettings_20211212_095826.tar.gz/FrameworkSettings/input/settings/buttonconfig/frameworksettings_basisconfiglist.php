<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:frameworksettings_basisconfig:0:0:FrameworkSettings:¤";
?>