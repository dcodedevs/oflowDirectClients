<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'vatCode' => 1,
  'name' => 1,
  'percentRate' => 1,
  'vatCodeMamutExport' => 1,
);
?>