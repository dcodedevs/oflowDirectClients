<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:vatcode:0:0:VatCode:¤";
?>