<?php
$sys_table_indexes = array('creditor_transaction_id:key:collecting_company_cases_claim_lines:creditor_transaction_id', 'collecting_company_case_id:key:collecting_company_cases_claim_lines:collecting_company_case_id', 'invoice_nr:key:collecting_company_cases_claim_lines:invoice_nr');
?>