<?php
$sys_table_indexes = array('collecting_company_case_id:key:case_worklist_connection:collecting_company_case_id', 'case_worklist_id:key:case_worklist_connection:case_worklist_id', 'closed_date:key:case_worklist_connection:closed_date');
?>