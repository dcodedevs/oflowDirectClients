<?php
$sys_table_indexes = array('collecting_company_case_id:key:collecting_company_case_paused:collecting_company_case_id', 'pause_reason:key:collecting_company_case_paused:pause_reason', 'closed_date:key:collecting_company_case_paused:closed_date');
?>