<?php
$sys_table_indexes = array('creditor_id:key:collecting_company_cases:creditor_id', 'debitor_id:key:collecting_company_cases:debitor_id', 'collecting_process_id:key:collecting_company_cases:collecting_process_id', 'collecting_cases_process_step_id:key:collecting_company_cases:collecting_cases_process_step_id');
?>