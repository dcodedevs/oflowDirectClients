<?php
$formText_SenderEmailAddressNeedsToTeDefinedForSendingInvitation_Output="Avsender epost må defineres for å sende invitasjon";
$formText_DomainNameNeedsToTeDefinedForSendingInvitation_Output="Domenenavn må defineres for å sende invitasjon";
$formText_CustomerMissingSelfdefinedCompany_output="Kunden mangler egendefinert firma";
?>