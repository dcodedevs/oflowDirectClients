<?php
$formText_SenderEmailAddressNeedsToTeDefinedForSendingInvitation_Output="";
$formText_DomainNameNeedsToTeDefinedForSendingInvitation_Output="";
$formText_CustomerMissingSelfdefinedCompany_output="";
?>