<?php
$formText_SenderEmailAddressNeedsToTeDefinedForSendingInvitation_Output="Sender email address needs to te defined for sending invitation";
$formText_DomainNameNeedsToTeDefinedForSendingInvitation_Output="Domain name needs to te defined for sending invitation";
$formText_CustomerMissingSelfdefinedCompany_output="Customer missing selfdefined company";
?>