<?php
$formText_InvitationConfigurationError_Output="Invitation configuration error";
?>