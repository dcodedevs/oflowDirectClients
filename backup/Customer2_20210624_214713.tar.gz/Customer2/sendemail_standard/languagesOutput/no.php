<?php
$formText_InvitationConfigurationError_Output="Feil i invitasjon konfig";
?>