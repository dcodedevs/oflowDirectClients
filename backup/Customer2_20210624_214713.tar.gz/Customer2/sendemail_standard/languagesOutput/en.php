<?php
$formText_InvitationFrom_InvitationEmail="Invitation from";
$formText_Hello_InvitationEmail="Hello";
$formText_NowYouHaveAccessToOurClosedWebpageOn_InvitationEmail="Now you have access to our closed webpage on";
$formText_HereYouWillFindProductInformationContactInformationAndMore_InvitationEmail="Here you will find product information contact information and more";
$formText_ClickHereToLogin_InvitationEmail="Click here to login";
$formText_Sincerely_InvitationEmail="Sincerely";
$formText_Signature_InvitationEmail="IFB Development 1";
$formText_HereYouWillFindProductInformationDrinkRecipesBrochuresPriceListsContactInformationAndMore_InvitationEmail="Here you will find product information drink recipes brochures price lists contact information and more";
$formText_Files_sendTemplate="Files";
?>