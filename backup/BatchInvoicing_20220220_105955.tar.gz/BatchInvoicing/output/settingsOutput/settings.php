<?php
$invoiceCheck_ArticleNumber = "1";
$invoiceCheck_VatCode = "1";
$invoiceCheck_ProjectFAccNumber = "1";

?>