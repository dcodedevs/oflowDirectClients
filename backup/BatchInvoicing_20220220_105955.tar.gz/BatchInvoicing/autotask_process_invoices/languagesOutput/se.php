<?php
$formText_MissingFilesToAttachToInvoice="Saknar filers som underlag till fakturan ";
$formText_InvoiceMissingExternalInvoiceNr="Fakturan saknar faktureringsnummer ";
$formText_IntegrationSyncingFailed="Integrationen synkroniserar felet  ";
$formText_InvoiceMissingKidNumber="Fakturan saknar kidnummer";
$formText_ErrorCreatingPdf="Ett fel uppstod under framtagandet av Pdf ";
$formText_MissingEhfConfigurationForVat_Output="Mva koden saknar konfigurering för Ehf";
$formText_EhfInvoiceFileValidationFailed_Output="Ehf faktura validerar felet ";
$formText_MoreInfo_Output="Mer info";
$formText_NotDelivered_Output="Levererades inte ";
$formText_InvoiceNumber_Output="Fakturanr";
$formText_InvalidEmailSpecified_Output="Ogiltig eposadress är specificerat  ";
$formText_InvoiceHasNotBeSentByEmailToCustomer_Output="Fakturan blev inte skickad till e-post ";
$formText_of_Output="av";
$formText_EmailAddressesIsInvalidForCustomer_Output="E-postadress är ogiltig ";
$formText_InvoicesForPrint_output="Fakturor som måste skrivas ut ";
$formText_Hi_output="Hej";
$formText_YouCanDownloadInvoicesForPrintFromBatchinvoicingModule_output="Fakturor som ska skrivas ut ligger klara för ned lastning i  batchfakturering modulen";
$formText_ClickHereToOpen_output="Klicka här för att öppna ";
$formText_ErrorSendingEmail_output="Ett fel uppstod vid utsändning av epost  ";
$formText_InvalidEmail_output="Ogiltig e-postadress ";
$formText_AutoTaskCannotBeFound_Output="Autotask hittades inte ";
?>