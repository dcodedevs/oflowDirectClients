<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'activateCheckForProjectNr' => 1,
  'activateCheckForDepartmentCode' => 1,
  'activate_ehf_check' => 1,
);
?>