/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'font', 'bg', {
	fontSize: {
		label: 'Размер',
		voiceLabel: 'Размер на шрифт',
		panelTitle: 'Размер на шрифт'
	},
	label: 'Шрифт',
	panelTitle: 'Име на шрифт',
	voiceLabel: 'Шрифт'
} );
