<?php
$formText_Objection_output="Melding vedr sak";
$formText_ObjectionWasAddedForCase="En melding ble lagt til på saken. Saken stanses inntil besvart og saken frigitt i kreditorportalen";
$formText_Case_output="Sak";
$formText_Customer_output="Kunde";
$formText_MessageFromDebitor="Melding fra debitor";
$formText_ErrorSendingEmail_output="En feil oppstod ved sending av epost";
$formText_NotDelivered_Output="Eposten ble ikke levert";
?>