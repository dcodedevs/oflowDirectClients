<?php
$formText_Objection_output="Objection";
$formText_ObjectionWasAddedForCase="Objection was added for case";
$formText_Case_output="Case";
$formText_Customer_output="Customer";
$formText_MessageFromDebitor="Message from debitor";
$formText_ErrorSendingEmail_output="Error sending email";
$formText_NotDelivered_Output="Not delivered";
?>