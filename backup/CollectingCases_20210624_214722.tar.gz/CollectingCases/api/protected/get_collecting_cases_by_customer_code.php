<?php
$ip = $v_data['params']['ip'];
$code = $v_data['params']['code'];

$s_sql = "select * from collecting_cases_debitor_codes_log where ip = ? AND successful = 0 AND created BETWEEN  DATE_FORMAT(NOW(), '%Y-%m-%d %H:00:00')  AND  DATE_FORMAT(NOW(), '%Y-%m-%d %H:59:59')";
$o_query = $o_main->db->query($s_sql, array($ip));
$attempts = $o_query ? $o_query->result_array() : array();

include(__DIR__."/../../output/includes/fnc_calculate_interest.php");
if(count($attempts) < 3){
    $s_sql = "INSERT INTO collecting_cases_debitor_codes_log SET code_used = ?, successful = 0, ip = ?, created = NOW()";
    $o_query = $o_main->db->query($s_sql, array($code, $ip));
    if($o_query){
        $log_id = $o_main->db->insert_id();
        $s_sql = "select * from collecting_cases_debitor_codes where code = ? AND expiration_time > NOW()";
        $o_query = $o_main->db->query($s_sql, array($code));
        $key_item = $o_query ? $o_query->row_array() : array();
        if($key_item) {
            $s_sql = "UPDATE collecting_cases_debitor_codes_log SET successful = 1 WHERE id = ?";
            $o_query = $o_main->db->query($s_sql, array($log_id));
            $v_return['status'] = 1;

            $s_sql = "select * from customer where id = ?";
            $o_query = $o_main->db->query($s_sql, array($key_item['customer_id']));
            $customer = $o_query ? $o_query->row_array() : array();


            $s_sql = "SELECT cc.*, CONCAT_WS(' ', c.name, c.middlename, c.lastname) as creditorName FROM collecting_cases cc
            LEFT OUTER JOIN creditor_invoice ci ON ci.collecting_case_id = cc.id
            LEFT JOIN creditor cred ON cred.id = cc.creditor_id
            LEFT JOIN customer c ON cred.customer_id = c.id
            WHERE cc.debitor_id = ? AND (cc.status = 0 OR cc.status is null OR cc.status = 1 OR cc.status = 3)
            ORDER BY cc.id";
            $o_query = $o_main->db->query($s_sql, array($customer['id']));
            $collecting_cases = $o_query ? $o_query->result_array() : array();
            $collecting_cases_final = array();
            foreach($collecting_cases as $collecting_case){

                $s_sql = "SELECT * FROM creditor_invoice WHERE content_status < 2 AND collecting_case_id = ? ORDER BY created DESC";
                $o_query = $o_main->db->query($s_sql, array($collecting_case['id']));
                $invoice = ($o_query ? $o_query->row_array() : array());

                $s_sql = "SELECT * FROM creditor_invoice WHERE content_status < 2 AND collecting_case_id = ? ORDER BY created DESC";
                $o_query = $o_main->db->query($s_sql, array($collecting_case['id']));
                $invoices = ($o_query ? $o_query->result_array() : array());

                $s_sql = "SELECT * FROM collecting_cases_claim_lines WHERE content_status < 2 AND collecting_case_id = ? ORDER BY claim_type ASC, created DESC";
                $o_query = $o_main->db->query($s_sql, array($collecting_case['id']));
                $claims = ($o_query ? $o_query->result_array() : array());

                $s_sql = "SELECT * FROM collecting_cases_payments WHERE collecting_case_id = ? ORDER BY created DESC";
                $o_query = $o_main->db->query($s_sql, array($collecting_case['id']));
                $payments = ($o_query ? $o_query->result_array() : array());

                $sql = "SELECT creditor_invoice_payment.* FROM creditor_invoice_payment
                WHERE creditor_invoice_payment.invoice_number = ? AND creditor_invoice_payment.creditor_id = ? AND (before_or_after_case = 1)";
                $o_query = $o_main->db->query($sql, array($invoice['invoice_number'], $invoice['creditor_id']));
                $payments_before = $o_query ? $o_query->result_array() : array();

                $s_sql = "SELECT * FROM collecting_cases_objection WHERE collecting_case_id = ? ORDER BY created DESC";
                $o_query = $o_main->db->query($s_sql, array($collecting_case['id']));
                $objections = ($o_query ? $o_query->result_array() : array());

                $s_sql = "SELECT * FROM collecting_cases_claim_letter WHERE case_id = ? ORDER BY created DESC";
                $o_query = $o_main->db->query($s_sql, array($collecting_case['id']));
                $lastletter = ($o_query ? $o_query->row_array() : array());

                $s_sql = "SELECT * FROM collecting_cases_main_status_basisconfig WHERE id = ? ORDER BY id ASC";
                $o_query = $o_main->db->query($s_sql, array(intval($collecting_case['status'])));
                $collecting_case_status = ($o_query ? $o_query->row_array() : array());

                $s_sql = "SELECT * FROM collecting_cases_sub_status_basisconfig WHERE id = ? ORDER BY id ASC";
                $o_query = $o_main->db->query($s_sql, array(intval($collecting_case['sub_status'])));
                $collecting_case_substatus = ($o_query ? $o_query->row_array() : array());

                $collecting_case['invoice'] = $invoice;
                $collecting_case['claims'] = $claims;
                $collecting_case['lastletter'] = $lastletter;
                $collecting_case['payments'] = $payments;
                $collecting_case['payments_before'] = $payments_before;
                $interestArray = calculate_interest($invoice, $collecting_case);
                $collecting_case['interestArray'] = $interestArray;
                $collecting_case['objections'] = $objections;
                $collecting_case['collecting_case_status'] = $collecting_case_status;
                $collecting_case['collecting_case_sub_status'] = $collecting_case_substatus;

                $collecting_case['invoices'] = $invoices;
                $collecting_cases_final[] = $collecting_case;
            }

            $v_return['customer'] = $customer;
            $v_return['collecting_cases'] = $collecting_cases_final;
        } else {
            $v_return['error'] = 'Wrong/expired code';
        }
    }
} else {
    $v_return['error'] = "Too many wrong requests. You have been suspended for 1 hour.";
}
?>
