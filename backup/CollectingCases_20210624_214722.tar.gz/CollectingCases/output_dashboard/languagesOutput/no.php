<?php
$formText_Cases_output="Saker";
$formText_ClaimlineTypes_output="Sakslinje typer";
$formText_CasesInReminderLevel_output="Saker i purrenivå";
$formText_CasesInCollectingLevel_output="Saker i inkassonivå";
$formText_NewCasesThisYear_output="Nye saker i år";
$formText_CompletedCasesInReminderLevel_output="Avsluttede saker i purrenivå";
$formText_CompletedCasesInCollectingLevel_output="Avsluttede saker i inkassonivå";
$formText_ClaimlineType_output="Sakslinje type";
$formText_CompletedCases_output="Avsluttede saker";
$formText_OpenCases_output="Åpne saker";
$formText_OriginalClaim_output="Hovedstol";
?>