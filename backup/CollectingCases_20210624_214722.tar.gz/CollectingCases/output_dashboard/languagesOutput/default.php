<?php
$formText_Cases_output="Cases";
$formText_ClaimlineTypes_output="Claimline types";
$formText_CasesInReminderLevel_output="Cases in reminder level";
$formText_CasesInCollectingLevel_output="Cases in collecting level";
$formText_NewCasesThisYear_output="New cases this year";
$formText_CompletedCasesInReminderLevel_output="Completed cases in reminder level";
$formText_CompletedCasesInCollectingLevel_output="Completed cases in collecting level";
$formText_ClaimlineType_output="Claimline type";
$formText_CompletedCases_output="Completed cases";
$formText_OpenCases_output="Open cases";
$formText_OriginalClaim_output="Original claim";
?>