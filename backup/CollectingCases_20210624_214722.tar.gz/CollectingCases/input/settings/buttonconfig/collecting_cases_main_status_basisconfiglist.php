<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:collecting_cases_main_status_basisconfig:0:0:CollectingCases:¤";
?>