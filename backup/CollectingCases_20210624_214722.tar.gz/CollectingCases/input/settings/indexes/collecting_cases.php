<?php
$sys_table_indexes = array('creditor_id:key:collecting_cases:creditor_id', 'debitor_id:key:collecting_cases:debitor_id');
?>