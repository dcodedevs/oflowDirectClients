<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'creditor_id' => 1,
  'debitor_id' => 1,
  'creditor_ref' => 1,
  'status' => 1,
  'collectinglevel' => 1,
  'collecting_cases_process_id' => 1,
  'last_change_date_for_process' => 1,
  'kid_number' => 1,
  'needs_creditor_approval' => 1,
  'approved_by_creditor' => 1,
  'onhold_by_creditor' => 1,
);
?>