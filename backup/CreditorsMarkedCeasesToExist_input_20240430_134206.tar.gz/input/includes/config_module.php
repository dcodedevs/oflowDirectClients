<?php
$v_content_status_class = array(0=>"", 1=>"inactive", 2=>"deleted", 3=>"history");
