<?php
$thisFieldType = 2;
$thisDatabaseField = "DATETIME";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is current date and time on server.");
