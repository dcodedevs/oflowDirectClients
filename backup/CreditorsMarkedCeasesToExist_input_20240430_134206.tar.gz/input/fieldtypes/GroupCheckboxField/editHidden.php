<?php
if(is_file(__DIR__."/edit.php")) include(__DIR__."/edit.php");
