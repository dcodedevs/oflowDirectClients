<?php
$fields[$fieldPos][6][$this->langfields[$a]] = str_replace(' ','',$_POST[$fieldName]);
