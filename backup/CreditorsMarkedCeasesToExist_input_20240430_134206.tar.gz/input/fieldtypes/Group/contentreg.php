<?php
$fields[$fieldPos][6][$this->langfields[$a]] = implode('¤',$_POST[$fieldName]);
