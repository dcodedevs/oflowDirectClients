<?php
$fields[$fieldPos][6][$this->langfields[$a]] = (empty($_POST[$fieldName]) ? $o_main->account_id : $_POST[$fieldName]);
