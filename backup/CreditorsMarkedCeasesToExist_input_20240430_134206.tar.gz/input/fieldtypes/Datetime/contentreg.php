<?php
$fields[$fieldPos][6][$this->langfields[$a]] = addslashes(date("Y-m-d H:i:s", strtotime($_POST[$fieldName])));
