<?php
/*if($fields[$fieldPos][10] == 1)
{
	//read-only field - no input
	//print $fields[$fieldPos][6][$this->langfields[$a]];
} else {*/
	$fields[$fieldPos][6][$this->langfields[$a]] = $_POST[$fieldName];
//}
