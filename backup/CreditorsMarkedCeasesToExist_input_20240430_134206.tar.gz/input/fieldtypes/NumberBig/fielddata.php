<?php
$thisFieldType = 60;
$thisDatabaseField = "BIGINT";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is number field (Big integer format).");
