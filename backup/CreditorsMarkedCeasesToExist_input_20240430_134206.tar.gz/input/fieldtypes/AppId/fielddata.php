<?php
$thisFieldType = 0;
$thisDatabaseField = "INT";
$thisShowOnList = 0;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is system field and is used for multi-tenant account data separation.");
?>