<?php
$thisFieldType = 0;
$thisDatabaseField = "TINYINT";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is checkbox which defines <b>true</b> or <b>false</b> what coresponds to checked or unchecked.

In DB it is saved like 1 or 0.");
