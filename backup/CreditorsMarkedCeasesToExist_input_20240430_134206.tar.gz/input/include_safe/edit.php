<?php
//check user permissions

//default include
include(__DIR__."/../includes/edit.php");
