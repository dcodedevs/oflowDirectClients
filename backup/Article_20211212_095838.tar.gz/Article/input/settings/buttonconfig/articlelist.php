<?php
$prebuttonconfig = "New article:{$formText_newArticle_module}:AddItem:article:0:0:Article¤";
?>