<?php
$prerelations = array("id¤CollectingCases¤collecting_cases_sub_status_basisconfig¤collecting_cases_main_status_id¤1¤¤¤¤¤{$formText_SubStatuses_Relation}¤¤¤¤¤¤");
?>
