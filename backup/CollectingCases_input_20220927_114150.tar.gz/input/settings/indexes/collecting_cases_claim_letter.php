<?php
$sys_table_indexes = array('case_id:key:collecting_cases_claim_letter:case_id', 'step_id:key:collecting_cases_claim_letter:step_id', 'sending_status:key:collecting_cases_claim_letter:sending_status', 'company_case_id:key:collecting_cases_claim_letter:collecting_company_case_id');
?>