<?php
$sys_table_indexes = array('payment_plan_id:key:collecting_cases_payment_plan_lines:collecting_cases_payment_plan_id');
?>