<?php
$sys_table_indexes = array('collecting_case_id:key:collecting_cases_messages_creditor:collecting_case_id');
?>