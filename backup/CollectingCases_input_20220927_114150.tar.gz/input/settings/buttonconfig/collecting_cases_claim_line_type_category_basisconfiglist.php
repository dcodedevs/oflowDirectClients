<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:collecting_cases_claim_line_type_category_basisconfig:0:0:CollectingCases:¤";
?>