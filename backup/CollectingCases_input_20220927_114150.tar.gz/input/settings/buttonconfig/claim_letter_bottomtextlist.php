<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:claim_letter_bottomtext:0:0:CollectingCases:¤";
?>