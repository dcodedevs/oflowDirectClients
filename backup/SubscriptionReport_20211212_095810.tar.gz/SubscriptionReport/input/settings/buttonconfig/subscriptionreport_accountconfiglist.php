<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:subscriptionreport_accountconfig:0:0:SubscriptionReport:¤";
?>