<?php
$prerelations = array("id¤Building¤building¤buildingOwnerId¤1¤¤¤¤¤¤¤¤¤","id¤OwnerCompany¤projectforaccounting¤ownercompany_id¤1¤¤¤¤¤{$formText_Project_Relation}¤¤¤¤");
?>