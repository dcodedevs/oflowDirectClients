<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:departmentforaccounting:0:0:OwnerCompany:¤";
?>