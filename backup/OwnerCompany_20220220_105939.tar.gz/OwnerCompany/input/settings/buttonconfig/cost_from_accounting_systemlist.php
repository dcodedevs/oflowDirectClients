<?php
$prebuttonconfig = "Sync cost from accounting:{$formText_SyncCostFromAccounting_module}:SyncCostFromAccounting:cost_from_accounting_system:0:0:OwnerCompany:¤";
?>