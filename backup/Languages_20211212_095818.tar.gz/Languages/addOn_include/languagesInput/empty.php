<?php
$formText_openPdf_input = '';
$formText_edit_list = '';
$formText_sendEmail_list = '';
$formText_sendSms_list = '';
$formText_sendPdf_list = '';
$formText_order_list = '';
$formText_contentsettings_list = '';
$formText_showPage_list = '';
$formText_DeleteItem_input = '';
$formText_delete_list = '';
$formText_Previous_input = '';
$formText_Next_input = '';
?>