<a href="<?php echo $edit_link;?>" id="<?php echo $button_ui_id;?>" class="optimize" role="menuitem"><?php echo $buttonsArray[1];?></a>
