<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:bookaccount:0:0:BookAccount:¤Sync book accounts:{$formText_SyncBookAccounts_module}:SyncBookAccounts:bookaccount:0:0:BookAccount:¤";
?>