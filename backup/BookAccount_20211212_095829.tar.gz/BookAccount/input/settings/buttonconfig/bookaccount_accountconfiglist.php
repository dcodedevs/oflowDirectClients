<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:bookaccount_accountconfig:0:0:BookAccount:¤";
?>