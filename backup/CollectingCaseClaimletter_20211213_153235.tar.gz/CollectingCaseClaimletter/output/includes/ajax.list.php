<?php
$subscriptiontype_filter = intval($_GET['subscriptiontype_filter']);

$s_sql = "SELECT * FROM subscriptiontype WHERE id = ? ORDER BY name";
$o_query = $o_main->db->query($s_sql, array($subscriptiontype_filter));
$subscriptionType = $o_query ? $o_query->row_array() : array();

$s_sql = "SELECT * FROM subscriptiontype_subtype WHERE subscriptiontype_id = ? ORDER BY name";
$o_query = $o_main->db->query($s_sql, array($subscriptiontype_filter));
$subscriptionSubTypes = $o_query ? $o_query->result_array() : array();

$list_filter = isset($_GET['list_filter']) ? $_GET['list_filter'] : 'absence';

$sql = "SELECT * FROM collecting_cases_claim_letter WHERE content_status < 2";
$o_query = $o_main->db->query($sql);
$all_count = $o_query ? $o_query->num_rows() : 0;

$sql = "SELECT * FROM collecting_cases_claim_letter WHERE content_status < 2 AND sending_status = 1";
$o_query = $o_main->db->query($sql);
$processed_count = $o_query ? $o_query->num_rows() : 0;

$sql = "SELECT * FROM collecting_cases_claim_letter WHERE content_status < 2 AND (sending_status is null OR sending_status = 0)";
$o_query = $o_main->db->query($sql);
$not_processed_count = $o_query ? $o_query->num_rows() : 0;

$sql = "SELECT * FROM collecting_cases_claim_letter WHERE content_status < 2 AND sending_status = 2";
$o_query = $o_main->db->query($sql);
$failed_count = $o_query ? $o_query->num_rows() : 0;
?>
<?php
include(__DIR__."/list_filter.php");

$sql_where = "";
if($list_filter == "not_processed"){
    $sql_where .= " AND (sending_status is null OR sending_status = 0)";
} else if($list_filter == "processed"){
    $sql_where .= " AND sending_status <> 0";
} else if($list_filter == "failed"){
    $sql_where .= " AND sending_status = 2";
}

$sql = "SELECT * FROM collecting_cases_claim_letter ccl
WHERE ccl.content_status < 2".$sql_where."
ORDER BY ccl.created DESC";
$o_query = $o_main->db->query($sql);
$letters = $o_query ? $o_query->result_array() : array();
$action_text = array(1=>$formText_SendLetter_output, 2=>$formText_SendEmailIfEmailExistsOrElseLetter_output);
$action_text_icons = array(1=>'<i class="fas fa-file"></i>', 2=>'<i class="fas fa-at"></i>');
$status_array = array(-1=>$formText_Processing_output, 0 => $formText_NotProcessed_output, 1=> $formText_Completed_output, 2=>$formText_Failed_output);
?>
<div id="p_container" class="p_container">
	<div class="p_containerInner">
		<div class="p_content">
			<div class="p_pageContent">
                <div class="p_pageDetails">
                    <div class="gtable" >
                        <div class="gtable_row">
                            <div class="gtable_cell gtable_cell_head"><input type="checkbox" class="selectAll" autocomplete="off"/></div>
                            <div class="gtable_cell gtable_cell_head"><?php echo $formText_Created_output;?></div>
                            <div class="gtable_cell gtable_cell_head"><?php echo $formText_CollectingCaseId_output;?></div>
                            <div class="gtable_cell gtable_cell_head"><?php echo $formText_SendingAction_output;?></div>
                            <div class="gtable_cell gtable_cell_head"><?php echo $formText_SendingStatus_output;?></div>
                            <div class="gtable_cell gtable_cell_head"><?php echo $formText_PerformedDate_output;?></div>
                            <div class="gtable_cell gtable_cell_head"><?php echo $formText_Letter_output;?></div>
                        </div>
                        <?php
                        foreach($letters as $letter) {
                            ?>
                            <div class="gtable_row">
                                <div class="gtable_cell">
                                    <input type="checkbox" class="checkboxesGenerate" name="casesToGenerate" autocomplete="off" value="<?php echo $letter['id'];?>" />
                                </div>
                                <div class="gtable_cell"><?php echo date("d.m.Y", strtotime($letter['created']));?></div>
                                <div class="gtable_cell"><?php echo $letter['case_id'];?></div>
                                <div class="gtable_cell"><?php if($letter['sending_status']) { echo $action_text[$letter['performed_action']]; } else {
                                    echo $action_text[$letter['sending_action']];
                                }?></div>
                                <div class="gtable_cell"><?php echo $status_array[$letter['sending_status']];?></div>
                                <div class="gtable_cell"><?php if($letter['performed_date'] != "0000-00-00"){ echo $letter['performed_date'];};?></div>
                                <div class="gtable_cell">
                                    <?php if($letter['pdf'] != "") { ?>
                                        <div class="project-file">
                                            <div class="project-file-file">
                                                <a href="<?php echo $extradomaindirroot.$letter['pdf'];?>" download><?php echo $formText_Download_Output;?></a>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
.p_pageDetails {
    background: #fff;
}
.edit_workplanlineworker {
    cursor: pointer;
    color: #46b2e2;
}
.gtable_cell_head {
    font-weight: bold;
}
.gtable {
    margin-top: 0px;
}
</style>
<script type="text/javascript">

$(function() {
    $(".selectAll").on("click", function(){
        if($(this).is(":checked")){
            $(".checkboxesGenerate").prop("checked", true);
        } else {
            $(".checkboxesGenerate").prop("checked", false);
        }
        $(".launchPdfGenerate .selected_letters").html($(".checkboxesGenerate:checked").length);
    });
    $(".checkboxesGenerate").off("click").on("click", function(){
        $(".launchPdfGenerate .selected_letters").html($(".checkboxesGenerate:checked").length);
    })

    $(".launchPdfGenerate").on("click", function(e){
        e.preventDefault();
        bootbox.confirm('<?php echo $formText_ProcessActions_output; ?>', function(result) {
            if (result) {
                var casesToGenerate = [];
                $(".checkboxesGenerate").each(function(index, el){
                    if($(el).is(":checked")){
                        casesToGenerate.push($(el).val());
                    }
                })
                var data = {
                    casesToGenerate: casesToGenerate
                }
                ajaxCall('process_letters', data, function(json) {
                    // var win = window.open('<?php echo $extradomaindirroot.'/modules/CollectingCases/output/ajax.download.php?ID=';?>' + json.data.batch_id, '_blank');
                    // win.focus();
                    var data = {
                        list_filter: '<?php echo $list_filter;?>'
                    };
                    loadView('list', data);
                });
            }
        });
    })
    $(document).off('click', '.output-click-helper').on('click', '.output-click-helper', function(e){
        if(e.target.nodeName == 'td'){
            <?php if($b_selection_mode && $totalPagesFiltered == 1) { ?>
            $(this).closest('.gtable_row').find('.selection-switch-btn').trigger('click');
            <?php } else { ?>
            fwAbortXhrPool();
            fw_load_ajax($(this).data('href'),'',true);
            if($("body.alternative").length == 0) {
                if($(this).parents(".tinyScrollbar.col1")){
                    var $scrollbar6 = $('.tinyScrollbar.col1');
                    $scrollbar6.tinyscrollbar();

                    var scrollbar6 = $scrollbar6.data("plugin_tinyscrollbar");
                    scrollbar6.update(0);
                }
            }
            <?php } ?>
        }
    });
    $(".edit_workplanlineworker").off("click").on("click", function(e){
        e.preventDefault();
        var data = {
            workplanlineworkerId: $(this).data("id"),
            repeatingOrderId: $(this).data("repeatingorderid"),
            projectId: $(this).data("projectid")
        }
        ajaxCall({module_file:'edit_workplanlineworker', module_name: 'EmployeePlanOverview', module_folder: 'output'}, data, function(json) {
            $('#popupeditboxcontent').html('');
            $('#popupeditboxcontent').html(json.html);
            out_popup = $('#popupeditbox').bPopup(out_popup_options);
            $("#popupeditbox:not(.opened)").remove();
        });
    })
})
</script>
