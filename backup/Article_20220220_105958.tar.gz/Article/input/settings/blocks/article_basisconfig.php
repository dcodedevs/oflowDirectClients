<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  0 => 
  array (
    'sys_name' => $formText_SystemArticleTypes_settingBlocks,
    'sys_childs' => 
    array (
      'activate_prepaid_commoncost_type' => 1,
      'activate_marketing_contribution_type' => 1,
      'activate_parking_rent_type' => 1,
      'activate_item_sales' => 1,
    ),
    'sys_collapse' => '1',
  ),
);
?>