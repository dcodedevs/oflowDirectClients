<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:article_set:0:0:Article:¤";
?>