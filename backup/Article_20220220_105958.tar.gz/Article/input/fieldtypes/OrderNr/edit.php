<?php
if($field[6][$langID] == "")
{
} else {
	if($access>=10)
	{
		?><input <?php echo $field_attributes;?> id="<?php echo $field_ui_id;?>" type="text" name="<?php echo $field[1].$ending;?>" value="<?php echo $field[6][$langID];?>" /><?php
	} else {
		print $field[6][$langID];
		?><input <?php echo $field_attributes;?> id="<?php echo $field_ui_id;?>" type="hidden" name="<?php echo $field[1].$ending;?>" value="<?php echo $field[6][$langID];?>" /><?php
	}
}
?>