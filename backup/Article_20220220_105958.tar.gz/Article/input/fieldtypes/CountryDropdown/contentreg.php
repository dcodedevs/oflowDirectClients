<?php
$fields[$fieldPos][6][$this->langfields[$a]] = addslashes($_POST[$fieldName]);
?>