<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'max_number_ownercompanies' => 1,
  'activate_global_external_company_id' => 1,
  'next_global_external_company_id' => 1,
  'global_integration' => 1,
  'lastProjectSyncDate' => 1,
  'global_export_script' => 1,
  'addAdminFeeAutomatically' => 1,
  'chooseArticleForAdminFee' => 1,
  'accountCodeRoundingsOnInvoice' => 1,
  'accountCodeCustomerLedger' => 1,
);
?>