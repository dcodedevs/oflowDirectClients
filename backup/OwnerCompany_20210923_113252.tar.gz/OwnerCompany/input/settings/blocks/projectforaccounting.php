<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'projectnumber' => 1,
  'name' => 1,
  'ownercompany_id' => 1,
  'parentId' => 1,
  'parentNumber' => 1,
);
?>