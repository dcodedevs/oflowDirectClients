<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:ownercompany_basisconfig:0:0:OwnerCompany:¤";
?>