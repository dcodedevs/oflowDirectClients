<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:projectforaccounting:0:0:OwnerCompany:¤";
?>