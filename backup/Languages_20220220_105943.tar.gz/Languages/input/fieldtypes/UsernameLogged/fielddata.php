<?php
$thisFieldType = 0;
$thisDatabaseField = "CHAR(255)";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is active user name, which is not displayed and it is saved automatically.");
?>