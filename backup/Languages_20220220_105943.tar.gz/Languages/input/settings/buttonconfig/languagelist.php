<?php
$prebuttonconfig = "New:{$formText_new_module}:AddItem:language:0:0:Languages¤";
?>