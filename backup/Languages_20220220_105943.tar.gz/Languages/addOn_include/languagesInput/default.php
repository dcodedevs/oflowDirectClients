<?php
$formText_openPdf_input = 'Open pdf';
$formText_edit_list = 'Edit';
$formText_sendEmail_list = 'Send email';
$formText_sendSms_list = 'Send sms';
$formText_sendPdf_list = 'Send pdf';
$formText_order_list = 'Order';
$formText_contentsettings_list = 'Contentsettings';
$formText_showPage_list = 'Show page';
$formText_DeleteItem_input = 'Delete item';
$formText_delete_list = 'Delete';
$formText_Previous_input = 'Previous';
$formText_Next_input = 'Next';
?>