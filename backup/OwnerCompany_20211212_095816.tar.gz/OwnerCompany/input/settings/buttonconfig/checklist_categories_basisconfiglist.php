<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:checklist_categories_basisconfig:0:0:OwnerCompany:¤";
?>