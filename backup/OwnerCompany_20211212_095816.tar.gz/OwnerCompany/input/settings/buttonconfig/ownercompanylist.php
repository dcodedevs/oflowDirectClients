<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:ownercompany:0:0:OwnerCompany:¤";
?>