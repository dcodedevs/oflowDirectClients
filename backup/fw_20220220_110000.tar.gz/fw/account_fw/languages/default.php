<?php
$formText_ModuleNotFound_ModuleContent="Module not found";
$formText_NoAccessToThisModule_ModuleContent="No access to this module";
$formText_DeveloperAccess_users="Developer access";
$formText_Language_Framework="Language";
$formText_adminUserinfo_getynetmenu="Admin userinfo";
$formText_AccountSettings_getynetmenu="Account settings";
$formText_AdminModules_FwMenu="Admin modules";
$formText_ShowProfile_AccountFrameworkMenu="Show profile";
$formText_YouAreAdminAndCanReadAndWriteToAllTagsAndGroups_framework="You are admin and can read and write to all tags and groups";
$formText_GroupsWrite_framework="Groups write";
$formText_TagsWrite_framework="Tags write";
$formText_GroupsRead_framework="Groups read";
$formText_TagsRead_framework="Tags read";
$formText_Statistic_AccountFrameworkMenu="Statistic";
$formText_ShowAllDepartments_AccountFrameworkMenu="Show all departments";
$formText_DepartmentsWithoutPage_AccountFrameworkMenu="Departments without page";
$formText_AddNewDepartment_AccountFrameworkMenu="Add new department";
$formText_Departments_AccountFrameworkMenu="Departments";
$formText_ShowAllGroups_AccountFrameworkMenu="Show all groups";
$formText_AddNewGroup_AccountFrameworkMenu="Add new group";
$formText_Groups_AccountFrameworkMenu="Groups";
$formText_Logout_blueline="Logout";
$formText_DeleteItem_framework="Delete item";
$formText_Yes_framework="Yes";
$formText_No_framework="No";
$formText_ErrorOccuredPleaseContactSupport_framework="Error occured please contact support";
?>