<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:dashboard_clean:0:0:DashboardClean:¤";
?>