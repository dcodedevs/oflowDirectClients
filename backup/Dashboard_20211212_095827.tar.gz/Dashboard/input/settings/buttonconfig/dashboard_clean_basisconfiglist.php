<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:dashboard_clean_basisconfig:0:0:DashboardClean:¤";
?>