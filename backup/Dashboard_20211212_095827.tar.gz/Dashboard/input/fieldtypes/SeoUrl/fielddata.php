<?php
$thisFieldType = 0;
$thisDatabaseField = "VARCHAR(1000)";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is single line text field specialy made for SEO Url - without standard input.");
?>