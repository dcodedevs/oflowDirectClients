<?php
$accessElementAllow_EditTopImage_description="Edit top image";
?>