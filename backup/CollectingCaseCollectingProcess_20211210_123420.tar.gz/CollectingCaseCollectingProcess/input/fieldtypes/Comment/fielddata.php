<?php
$thisFieldType = 0;
$thisDatabaseField = "LONGTEXT";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is for comments input, where more comments can be added in one field. Each comment have timestamp and user who added this comment.");
?>