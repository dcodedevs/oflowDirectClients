<?php
$developeraccesslevels = array(
	0=>$formText_Normal_UserAccess,
	5=>$formText_Extra_UserAccess,
	/*10=>$formText_Designer_UserAccess,*/
	20=>$formText_Developer_UserAccess
);
$developeraccessmodules = array('csseditor'=>10,'languages'=>20,'libraryload'=>20,'mainlayout'=>20,'modulemanager'=>20);
?>