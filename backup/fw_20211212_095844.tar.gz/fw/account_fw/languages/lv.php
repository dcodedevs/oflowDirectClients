<?php
$formText_ModuleNotFound_ModuleContent="Modulis netika atrasts";
$formText_NoAccessToThisModule_ModuleContent="Nav piekļuves šim modulim";
$formText_DeveloperAccess_users="Izstrādātāja piekļuve";
$formText_Language_Framework="Valoda";
$formText_adminUserinfo_getynetmenu="Lietotāju pārvalde";
$formText_AccountSettings_getynetmenu="Account settings";
$formText_AdminModules_FwMenu="Admin moduļi";
$formText_ShowProfile_AccountFrameworkMenu="Rādīt profilu";
$formText_YouAreAdminAndCanReadAndWriteToAllTagsAndGroups_framework="You are admin and can read and write to all tags and groups";
$formText_GroupsWrite_framework="Groups write";
$formText_TagsWrite_framework="Tags write";
$formText_GroupsRead_framework="Groups read";
$formText_TagsRead_framework="Tags read";
$formText_Statistic_AccountFrameworkMenu="Statistika";
$formText_ShowAllDepartments_AccountFrameworkMenu="Show departments with no access";
$formText_DepartmentsWithoutPage_AccountFrameworkMenu="Departments without page";
$formText_AddNewDepartment_AccountFrameworkMenu="Add new department";
$formText_Departments_AccountFrameworkMenu="Departamenti";
$formText_ShowAllGroups_AccountFrameworkMenu="Show groups with no access";
$formText_AddNewGroup_AccountFrameworkMenu="Add new group";
$formText_Groups_AccountFrameworkMenu="Grupas";
$formText_Logout_blueline="Izlogoties";
$formText_DeleteItem_framework="Dzēst vienumu";
$formText_Yes_framework="Jā";
$formText_No_framework="Nē";
$formText_ErrorOccuredPleaseContactSupport_framework="Notikusi kļūda! Ja tas atkārtojas, sazinieties ar Atbalsta dienestu.";
?>