<?php
$formText_ModuleNotFound_ModuleContent="Module er ikke funnet";
$formText_NoAccessToThisModule_ModuleContent="Ingen tilgang til denne modulen";
$formText_DeveloperAccess_users="Tilgangsnivå";
$formText_Language_Framework="Språk";
$formText_adminUserinfo_getynetmenu="Bruker administrering";
$formText_AccountSettings_getynetmenu="Account settings";
$formText_AdminModules_FwMenu="Admin moduler";
$formText_ShowProfile_AccountFrameworkMenu="Vis profil";
$formText_YouAreAdminAndCanReadAndWriteToAllTagsAndGroups_framework="Du er admin og kan lese og skrive til alle eiendomsgrupper og eiendommer";
$formText_GroupsWrite_framework="Eiendomsgrupper du kan skrive til";
$formText_TagsWrite_framework="Eiendommer du kan skrive til";
$formText_GroupsRead_framework="Eiendomsgrupper du kan lese fra";
$formText_TagsRead_framework="Eiendommer du kan lese fra";
$formText_Statistic_AccountFrameworkMenu="Statistikk";
$formText_ShowAllDepartments_AccountFrameworkMenu="Avdelinger uten tilgang";
$formText_DepartmentsWithoutPage_AccountFrameworkMenu="Departments without page";
$formText_AddNewDepartment_AccountFrameworkMenu="Legg til avdeling";
$formText_Departments_AccountFrameworkMenu="Avdelingssider";
$formText_ShowAllGroups_AccountFrameworkMenu="Gruppesider du ikke er medlem i";
$formText_AddNewGroup_AccountFrameworkMenu="Opprett ny gruppeside";
$formText_Groups_AccountFrameworkMenu="Gruppesider";
$formText_Logout_blueline="Logg ut";
$formText_DeleteItem_framework="Slette element";
$formText_Yes_framework="Ja";
$formText_No_framework="Nei";
$formText_ErrorOccuredPleaseContactSupport_framework="En feil oppstod. Sjekk om du er tilkoblet internett. Om feilen gjentar seg kontakt support.";
?>