<?php

// http://developer.24sevenoffice.com/

class Integration24SevenOffice {
    function __construct($config) {
        session_destroy();
        $this->ownercompany_id = isset($config['ownercompany_id']) ? $config['ownercompany_id'] : 0;
        $this->o_main = $config['o_main'];
        $this->identityId = isset($config['identityId']) ? $config['identityId'] : 0;
        $this->creditorId = isset($config['creditorId']) ? $config['creditorId'] : 0;
        $this->options = array ('trace' => true , 'encoding'=>' UTF-8');
        $this->auth(isset($config['getIdentityIdByName']) ? $config['getIdentityIdByName'] : '');
    }

    /**
     * API session handing
     * this auth() is taken from sample
     */


    function get_local_config() {
        if($this->creditorId > 0){

            require_once(__DIR__."/../../CreditorsOverview/output/includes/fnc_password_encrypt.php");
            $s_sql = "SELECT * FROM integration24sevenoffice";
            $o_query = $this->o_main->db->query($s_sql);
            $config = $o_query ? $o_query->row_array() : array();

            $sql = "SELECT * FROM creditor WHERE id = ?";
            $o_query = $this->o_main->db->query($sql, array($this->creditorId));
            $creditorData = $o_query ? $o_query->row_array() : array();
            $config['username'] = $creditorData['24sevenoffice_username'];
            $config['password'] = decrypt($creditorData['24sevenoffice_password'], "uVh1eiS366");
            $config['identity_name'] = $creditorData['24sevenoffice_identityname'];
        } else {
            if ($this->ownercompany_id) {
                $s_sql = "SELECT * FROM integration24sevenoffice WHERE ownerCompanyId = ?";
                $o_query = $this->o_main->db->query($s_sql, array($this->ownercompany_id));
                if($o_query && $o_query->num_rows()>0) $config = $o_query->row_array();
            } else {
                $s_sql = "SELECT * FROM integration24sevenoffice";
                $o_query = $this->o_main->db->query($s_sql);
                if($o_query && $o_query->num_rows()>0) $config = $o_query->row_array();
            }
        }

        // Return
        return $config;
    }

    function auth($getIdentityIdByName = "") {
        session_start();
        $config = $this->get_local_config();
        if($getIdentityIdByName == ""){
            $getIdentityIdByName = $config['identity_name'];
        }
        $username = $config['username'];  //Change this to your client user or community login
        $password = $config['password'];  //Change this to your password
        $applicationid = $config['applicationId'];  //Change this to your applicationId

        $params ["credential"]["Username"] = $username;
        // $encodedPassword = md5(mb_convert_encoding($password, 'utf-16le', 'utf-8')); //not supported anymore
        $params ["credential"]["Password"] = $password;
        $params ["credential"]["ApplicationId"] = $applicationid;

        // $params ["credential"]["IdentityId"] = "00000000-0000-0000-0000-000000000000";

        try {
            $authentication = new SoapClient ( "https://api.24sevenoffice.com/authenticate/v001/authenticate.asmx?wsdl", $this->options );
            // log into 24SevenOffice if we don't have any active session. No point doing this more than once.
            $login = true;
            if (!empty($_SESSION['ASP.NET_SessionId']))
            {
                $authentication->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);
                try
                {
                     $login = !($authentication->HasSession()->HasSessionResult);
                }
                catch ( SoapFault $fault )
                {
                    $login = true;
                }
            }
            if( $login )
            {
                if($this->identityId == "") {
                    $identities = $authentication->GetIdentitiesWithCredential($params);
                    $identiryResult = $identities->GetIdentitiesWithCredentialResult->Identity;
                    $this->identities = $identiryResult;
                    $identityId = "";

                    if(is_array($identiryResult)){
                        if($getIdentityIdByName != ""){
                            foreach($identiryResult as $identityResultSingle){
                                $client = $identityResultSingle->User;
                                if(mb_strtolower($client->Name,'UTF-8') == mb_strtolower($getIdentityIdByName, 'UTF-8')) {
                                    $identityId  = $identityResultSingle->Id;
                                } else {
                                    $client = $identityResultSingle->Client;
                                    if(mb_strtolower($client->Name,'UTF-8') == mb_strtolower($getIdentityIdByName, 'UTF-8')) {
                                        $identityId  = $identityResultSingle->Id;
                                    }
                                }

                            }
                        }
                    } else {
                        $client = $identiryResult->Client;
                        $identityId  = $identiryResult->Id;
                    }

                    $this->identityId = $identityId;
                    if($identityId != ""){
                        if($this->creditorId > 0){
                            $s_sql = "UPDATE creditor SET entity_id = ? WHERE id = ?";
                            $o_query = $this->o_main->db->query($s_sql, array($identityId, $this->creditorId));
                        } else {
                            $s_sql = "UPDATE ownercompany SET identity_id = ? WHERE id = ?";
                            $o_query = $this->o_main->db->query($s_sql, array($identityId, $this->ownercompany_id));
                        }
                    }

                }

                $params["credential"]["IdentityId"] = $this->identityId;
                if($params["credential"]["IdentityId"] != ""){
                    $result = ($temp = $authentication->Login($params));
                    // set the session id for next time we call this page
                    $_SESSION['ASP.NET_SessionId'] = $result->LoginResult;

                    // each seperate webservice need the cookie set
                    $authentication->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);
                    // throw an error if the login is unsuccessful
                    if($authentication->HasSession()->HasSessionResult == false)
                        throw new SoapFault("0", "Invalid credential information.");
                } else {
                    $this->error = "No Identity found";
                }
            }

        }
        catch ( SoapFault $fault )
        {
            $this->error = 'Exception: ' . $fault->getMessage();
        }
    }

    function get_customer_list($data = array()) {
        $service = new SoapClient ("https://api.24sevenoffice.com/CRM/Company/V001/CompanyService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        if(count($data['customerIds']) > 0){
            $searchParams = array(
                'CompanyName' => '%',
                'CompanyIds' => $data['customerIds']
            );
        } else {
            $searchParams = array(
                'CompanyName' => '%',
                'ChangedAfter' => isset($data['changedAfter']) ? date("Y-m-d", strtotime($data['changedAfter'])) : date("Y-m-d", strtotime("01.01.2000"))
            );
        }

        $returnProperties = array('Addresses', 'PhoneNumbers', 'EmailAddresses', 'OrganizationNumber');

        $params = array(
            'searchParams' => $searchParams,
            'returnProperties' => $returnProperties
        );

        $result = $service->GetCompanies($params);

        // Convert to array
        $result = json_decode(json_encode($result), true);

        return $result;
    }

    function add_customer($data) {
        $return = array();
        $service = new SoapClient ("https://api.24sevenoffice.com/CRM/Company/V001/CompanyService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        if ($data['customerName']) $data['name'] = $data['customerName'];

        //required field
        if($data['mailAddress']['Country'] == "" || $data['mailAddress']['Country'] == null){
            $data['mailAddress']['Country'] = "NO";
        }
        $company = array(
            'Name' => $data['name'],
            'Type' => 'Business', // hardcoded,
            'Addresses'=> array(
                'Post'=> $data['mailAddress']
            ),
            'EmailAddresses'=> array(
                'Invoice'=>array(
                    'Name' => $data['invoiceEmail'],
                    'Value' => $data['invoiceEmail']
                )
            ),
            'OrganizationNumber'=>$data['vatNumber'],
            'PaymentTime'=>$data['daysUntilDueDate']
        );
        if($data['external_id'] > 0){
            $company['Id'] = $data['external_id'];
        }
        $companies = array($company);
        $params = array(
            'companies' => $companies
        );
        $result = $service->SaveCompanies($params);
        $result = json_decode(json_encode($result), true);
        if(!isset($result['SaveCompaniesResult']['Company']['APIException']) && isset($result['SaveCompaniesResult']['Company'])) {
            $result = $result['SaveCompaniesResult']['Company'];

            if(intval($data['external_id']) == 0){
                $this->o_main->db->query("INSERT INTO customer_externalsystem_id
                SET created = NOW(),
                ownercompany_id = ?,
                customer_id = ?,
                external_id = ?", array($data['ownercompany_id'], $data['id'], $result['Id']));
            }
            $return = array(
                'id' => $result['Id'],
                'customerNumber' => $result['Id'],
                'name' => $result['Name']
            );

        } else {
            if(isset($result['SaveCompaniesResult']['Company']['APIException'])){
                $return = array(
                    "error" => $result['SaveCompaniesResult']['Company']['APIException'],
                    "params" => $params
                );
            } else {
                $return = array(
                    "error" => $result['error'],
                    "params" => $params
                );
            }
        }

        return $return;
    }

    function update_customer($data) {
        return $this->add_customer($data);
    }

    function get_invoice_list($data) {
        try {
            // error_reporting(E_ALL);
            // ini_set("display_errors", 1);
            $service = new SoapClient ("https://api.24sevenoffice.com/Economy/InvoiceOrder/V001/InvoiceService.asmx?WSDL", $this->options);
            $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);


            $searchParams = array(
                'CustomerIds' => $data['customerIds'],
                'ChangedAfter' => isset($data['changedAfter']) ? date("Y-m-d", strtotime($data['changedAfter'])) : date("Y-m-d", strtotime("01.01.2000")),
                'InvoiceIds' => $data['invoiceIds'],
                'OrderStatus' => 'Invoiced'
            );

            $returnProperties = array('InvoiceId', 'OrderId', 'CustomerId', 'CustomerName', 'Addresses', 'OrderStatus', 'DateOrdered', 'DateInvoiced', 'PaymentTime', 'DateChanged', 'PaymentAmount','PaymentMethodId',
            'OurReference', 'YourReference', 'ReferenceNumber', 'InvoiceRows', 'OrderTotalVat', 'OrderTotalIncVat', 'Paid','Closed', 'ExternalStatus', 'OCR');
            $rowReturnProperties = array('ProductId', 'RowId', 'Name', 'Quantity', 'Type', 'Price');

            $params = array(
                'searchParams' => $searchParams,
                'invoiceReturnProperties' => $returnProperties,
                'rowReturnProperties' => $rowReturnProperties
            );
            // var_dump($service);
            $result = $service->GetInvoices($params);
            // Convert to array
            $result = json_decode(json_encode($result), true);
        }
        catch ( SoapFault $fault )
        {
            $this->error = 'Exception: ' . $fault->getMessage();
        }
        return $result;
    }

    function add_invoice($data) {
        $service = new SoapClient ("https://api.24sevenoffice.com/Economy/InvoiceOrder/V001/InvoiceService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        $lines = $data['lines'];

        $preparedRows = array();
        foreach($lines as $line) {

            $preparedRows[] = array(
                'Name' => htmlspecialchars($line['description']),
                'InPrice' => 0,
                'Price' => $line['amount'],
                'Quantity' => $line['count'],
                'DiscountRate' => $line['discount'],
                'ProductId' => $line['external_product_id'],
            );
        }

        if(intval($data['departmentCode']) == 0){
            $data['departmentCode'] = null;
        }
        if(intval($data['projectCode']) == 0){
            $data['projectCode'] = null;
        }
        if(intval($data['orderId']) == 0){
            $data['orderId'] = null;
        }
        $params = array(
            'invoices' => array(
                 array(
                    'OrderId' => $data['orderId'],
                    'OrderStatus' => 'Invoiced',
                    'CustomerId' => $data['customerCode'],
                    'DateInvoiced' => $data['date'],
                    'InvoiceRows' => $preparedRows,
                    'DepartmentId' => $data['departmentCode'],
                    'ProjectId' => $data['projectCode'],
                    'Distributor' => "Manual"
                )
            )
        );
        try{
            $result = $service->SaveInvoices($params);
            $result = json_decode(json_encode($result), true);
        } catch ( SoapFault $fault )
        {
            $this->error = 'Exception: ' . $fault->getMessage();
            $result['error'] = $fault;
        }
        return $result;
    }

    function save_product($data) {
        $service = new SoapClient ("https://api.24sevenoffice.com/Logistics/Product/V001/ProductService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        $product_category_id = $this->save_product_category();

        $params = array(
            'products' => array(
                0 => array(
                    'ProductId' => $data['id'],
                    'CategoryId' => $product_category_id,
                    'Name' => $data['name'],
                    'Price' => $data['priceWithoutVat'],
                    'Cost' => $data['costWithoutVat'],
                    'No' => $data['article_code'],
                    'TaxRate' => $data['vat'],
                )
            )
        );
        $result = $service->SaveProducts($params);
        $result = json_decode(json_encode($result), true);
        $product = $result['SaveProductsResult']['Product'];
        $processed_product = array();
        if($product){
            $processed_product['id'] = $product['Id'];
        } else {
            $processed_product['error'] = 'Error adding product';
        }
        return $processed_product;
    }

    function get_transactions($data) {
        $service = new SoapClient ("https://api.24sevenoffice.com/Economy/Accounting/V001/TransactionService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        $params = array(
            'searchParams' => array(
                'DateSearchParameters' => "EntryDate",
                'DateStart' => ($data['date_start'] != "") ? $data['date_start'] : date('Y-m-d', time() - 60*60*24*365),
                'DateEnd' =>  ($data['date_end'] != "") ? $data['date_end'] : date('Y-m-d', time() + 60*60*24),
                'SystemType'=> $data['SystemType'],
                'InvoiceNo' => $data['InvoiceNo'],
                'ShowOpenEntries' => $data['ShowOpenEntries'],
                'HasInvoiceId' => $data['HasInvoiceId'],
                'LinkId' => $data['LinkId']
            )
        );
        $result = $service->GetTransactions($params);
        $result = json_decode(json_encode($result), true);
        $transactions = $result['GetTransactionsResult']['Transaction'];

        $transactions_processed = array();

        if (count($transactions) > 0) {
            if(!isset($transactions[0]['Date'])){
                $transactions = array($transactions);
            }
            foreach ($transactions as $transaction) {
                array_push($transactions_processed, array(
                    'date' => $transaction['Date'],
                    'accountNr' => $transaction['AccountNo'],
                    'transactionNr' => $transaction['TransactionNo'],
                    'invoiceNr' => $transaction['InvoiceNo'],
                    'amount' => $transaction['Amount'],
                    'dueDate' => $transaction['DueDate'],
                    'kidNumber' => $transaction['OCR'],
                    'systemType' => $transaction['SystemType'],
                    'linkId' => $transaction['LinkId'],
                    'open' => $transaction['Open'],
                    'hidden'=>$transaction['Hidden'],
                    'dateChanged'=>$transaction['DateChanged'],
                    'dimensions'=>$transaction['Dimensions'],
                    'id' => $transaction['Id']

                ));
            }
        }

        return $transactions_processed;
    }

    function get_products_list() {
        $service = new SoapClient ("https://api.24sevenoffice.com/Logistics/Product/V001/ProductService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

		/*Id Int32 Default value: Int32.MinValue
		Name String Max length 125 characters
		Stock Decimal Default value: Decimal.MinValue
		StatusId Int32 Default value: Int32.MinValue
		CategoryId Int32 Default value: Int32.MinValue
		PriceGroupID Int32 Default value: Int32.MinValue
		InPrice Decimal Default value: Decimal.MinValue
		Description String Max length 500 characters
		DescriptionLong String characters
		Cost Decimal Default value: typeof(Decimal
		EAN1 String Max length 50 characters
		Price Decimal Default value: Decimal.MinValue
		No String Max length 100 characters
		DateChanged DateTime Default value: DateTime.MinValue
		APIException Office24Seven.WebService.Library.Common.APIException Default value: null
		Weight Decimal Default value: Decimal.MinValue
		MinimumStock Decimal Default value: Decimal.MinValue
		OrderProposal Decimal Default value: Decimal.MinValue
		StockLocation String Max length 100 characters
		SupplierProductCode String Max length 50 characters
		SupplierProductName String Max length 250 characters
		Web Boolean*/

        $params = array(
            'searchParams' => array('Name' => '%'),
            'returnProperties' => array('Id', 'Name', 'Stock', 'CategoryId', 'Price', 'No', 'Description', 'DescriptionLong', 'Web','TaxRate')
        );

        $result = $service->GetProducts($params);
        $result = json_decode(json_encode($result), true);
        $products = $result['GetProductsResult']['Product'];

        $products_processed = array();

        if ($products) {
            if(!isset($products[0]['Id'])){
                $products = array($products);
            }
            foreach ($products as $product) {
                array_push($products_processed, array(
                    'id' => $product['Id'],
                    'name' => isset($product['Name']) ? $product['Name'] : '',
                    'stock' => isset($product['Stock']) ? $product['Stock'] : '',
                    'price' => isset($product['Price']) ? $product['Price'] : '',
                    'categoryId' => isset($product['CategoryId']) ? $product['CategoryId'] : '',
					'no' => isset($product['No']) ? $product['No'] : '',
					'description' => isset($product['Description']) ? $product['Description'] : '',
					'description_long' => isset($product['DescriptionLong']) ? $product['DescriptionLong'] : '',
					'status' => isset($product['Web']) ? $product['Web'] : '',
					'taxRate' => isset($product['TaxRate']) ? $product['TaxRate'] : ''
                ));
            }
        }

        return $products_processed;
    }

    function save_product_category(){
        $service = new SoapClient ("https://api.24sevenoffice.com/Logistics/Product/V001/ProductService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);
        $categories = $this->get_product_categories();
        $categoryId = null;
        foreach($categories as $category){
            if($category['name'] == "Getynet article"){
                $categoryId = $category['id'];
            }
        }
        $params = array(
            'categories' => array(
                0 => array(
                    'Id' => $categoryId,
                    'Name' => "Getynet article"
                )
            )
        );
        $result = $service->SaveCategories($params);
        $result = json_decode(json_encode($result), true);

        return $result;
    }

    function get_product_categories() {
        $service = new SoapClient ("https://api.24sevenoffice.com/Logistics/Product/V001/ProductService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        $params = array(
            'returnProperties' => array('Id', 'Name', 'ParentId')
        );

        $result = $service->GetCategories($params);
        $result = json_decode(json_encode($result), true);

        $categories = $result['GetCategoriesResult']['Category'];

        $categories_processed = array();

        if ($categories) {
            if(!isset($categories[0]['Id'])){
                $categories = array($categories);
            }
            // var_dump($categories);
            foreach ($categories as $category) {
                array_push($categories_processed, array(
                    'id' => $category['Id'],
                    'name' => $category['Name'],
                    'parentId' => $category['ParentId']
                ));
            }
        }

        return $categories_processed;
    }

    function get_orders_list($data = array()) {
        $service = new SoapClient ("https://api.24sevenoffice.com/Economy/InvoiceOrder/V001/InvoiceService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        $params = array(
            'invoiceReturnProperties' => array(
                'OrderId', 'CustomerId', 'CustomerName', 'DateOrdered', 'OrderTotalIncVat', 'OrderTotalVat', 'ReferenceNumber'
            ),
            'rowReturnProperties' => array(
                'ProductId', 'RowId', 'VatRate', 'Price', 'Name', 'DiscountRate', 'Quantity', 'Cost', 'InPrice'
            ),
            'searchParams' => array(
                'ChangedAfter' => '1970-01-01'// it demands at least one filter param
            )
        );
		if(count($data['customerIds'])>0)
		{
			$params['searchParams']['CustomerIds'] = $data['customerIds'];
		}

        $result = $service->GetInvoices($params);
        $result_converted = json_decode(json_encode($result), true); // convert to array
        $return = array();

        if ($result_converted['GetInvoicesResult']['InvoiceOrder']) {
            foreach ($result_converted['GetInvoicesResult']['InvoiceOrder'] as $row) {

                $order_rows = array();

                if ($row['InvoiceRows']['InvoiceRow']) {
                    foreach ($row['InvoiceRows']['InvoiceRow'] as $order_row) {
                        array_push($order_rows, array(
                            'id' => $order_row['RowId'],
                            'name' => $order_row['Name'],
                            'productId' => $order_row['ProductId'],
                            'price' => $order_row['Price'],
                            'cost' => $order_row['Cost'],
                            'quantity' => $order_row['Quantity'],
                            'discountRate' => $order_row['DiscountRate'],
                            'vatRate' => $order_row['VatRate']
                        ));
                    }
                }

                array_push($return, array(
                    'orderId' => $row['OrderId'],
                    'customerName' => $row['CustomerName'],
                    'customerId' => $row['CustomerId'],
                    'date' => date('Y-m-d H:i:s', strtotime($row['DateOrdered'])),
                    'totalIncVat' => $row['OrderTotalIncVat'],
                    'totalVat' => $row['OrderTotalVat'],
                    'total' => $row['OrderTotalIncVat'] - $row['OrderTotalVat'],
					'referenceNumber' => $row['ReferenceNumber'],
                    'orderLines' => $order_rows
                ));
            }
        }
        else {
            $return = array(
                'error' => 1
            );
        }

        return $return;
    }

	function get_orders_lines($data = array()) {
        $service = new SoapClient ("https://api.24sevenoffice.com/Economy/InvoiceOrder/V001/InvoiceService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

        $params = array(
            'invoiceReturnProperties' => array(
                'OrderId', 'CustomerId', 'CustomerName', 'DateOrdered', 'OrderTotalIncVat', 'OrderTotalVat', 'ReferenceNumber'
            ),
            'rowReturnProperties' => array(
                'ProductId', 'RowId', 'VatRate', 'Price', 'Name', 'DiscountRate', 'Quantity', 'Cost', 'InPrice'
            ),
            'searchParams' => array(
                'ChangedAfter' => '1970-01-01'// it demands at least one filter param
            )
        );
		if(count($data['orderIds'])>0)
		{
			$params['searchParams']['OrderIds'] = $data['orderIds'];
		}

        $result = $service->GetInvoices($params);
        $result_converted = json_decode(json_encode($result), true); // convert to array
        $return = array();

        if ($result_converted['GetInvoicesResult']['InvoiceOrder']) {
            $row = $result_converted['GetInvoicesResult']['InvoiceOrder'];

			$order_rows = array();

			if ($row['InvoiceRows']['InvoiceRow']) {
				foreach ($row['InvoiceRows']['InvoiceRow'] as $order_row) {
					array_push($order_rows, array(
						'id' => $order_row['RowId'],
						'name' => $order_row['Name'],
						'productId' => $order_row['ProductId'],
						'price' => $order_row['Price'],
						'cost' => $order_row['Cost'],
						'quantity' => $order_row['Quantity'],
						'discountRate' => $order_row['DiscountRate'],
						'vatRate' => $order_row['VatRate']
					));
				}
			}

			array_push($return, array(
				'orderId' => $row['OrderId'],
				'customerName' => $row['CustomerName'],
				'customerId' => $row['CustomerId'],
				'date' => date('Y-m-d H:i:s', strtotime($row['DateOrdered'])),
				'totalIncVat' => $row['OrderTotalIncVat'],
				'totalVat' => $row['OrderTotalVat'],
				'total' => $row['OrderTotalIncVat'] - $row['OrderTotalVat'],
				'referenceNumber' => $row['ReferenceNumber'],
				'orderLines' => $order_rows
			));
        }
        else {
            $return = array(
                'error' => 1
            );
        }

        return $return;
    }

    function get_projects_list() {
        $service = new SoapClient ("https://webservices.24sevenoffice.com/Project/V001/ProjectService.asmx?WSDL", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);
        $params = array(
            'Ps' => array(),
        );
        $result = $service->GetProjectList($params);
        $result = json_decode(json_encode($result), true);
        $list = $result['GetProjectListResult']['Project'];

        $return_list = array();

        // return $list;

        foreach ($list as $item) {
            array_push($return_list, array(
                'code' => $item['Id'],
                'description' => $item['Name'],
                'ownerCode' => '',
                'parentCode' => ''
            ));
        }

        return $return_list;
    }

    function get_account_list() {
        $service = new SoapClient ("https://webservices.24sevenoffice.com/economy/accountV002/Accountservice.asmx?wsdl", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);
        $params = array(
            'Ps' => array(),
        );
        $result = $service->GetAccountList($params);
        $result = json_decode(json_encode($result), true);
        $list = $result['GetAccountListResult']['AccountData'];

        $return_list = array();

        foreach ($list as $item) {
            array_push($return_list, array(
                'id' => $item['AccountId'],
                'code' => $item['AccountNo'],
                'name' => $item['AccountName'],
                'full_name' => $item['AccountName'],
                'account_tax' => isset($item['AccountTax']) ? $item['AccountTax'] : '',
                'tax_no' => isset($item['TaxNo']) ? $item['TaxNo'] : ''
            ));
        }

        return $return_list;
    }
    function get_tax_code_list() {
        $service = new SoapClient ("https://webservices.24sevenoffice.com/economy/accountV002/Accountservice.asmx?wsdl", $this->options);
        $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);
        $params = array(
            'Ps' => array(),
        );
        $result = $service->GetTaxCodeList($params);
        $result = json_decode(json_encode($result), true);
        $list = $result['GetTaxCodeListResult']['TaxCodeElement'];

        $return_list = array();

        foreach ($list as $item) {
            array_push($return_list, array(
                'id' => $item['TaxId'],
                'tax_no' => $item['TaxNo'],
                'tax_name' => $item['TaxName'],
                'tax_rate' => $item['TaxRate'],
                'account_no' => $item['AccountNo']
            ));
        }

        return $return_list;
    }

    function get_invoice_pdf($data = array()) {
        try {
            // error_reporting(E_ALL);
            // ini_set("display_errors", 1);
            $service = new SoapClient ("https://api.24sevenoffice.com/Economy/InvoiceOrder/V001/InvoiceService.asmx?WSDL", $this->options);
            $service->__setCookie("ASP.NET_SessionId", $_SESSION['ASP.NET_SessionId']);

            $searchParams = array(
                'InvoiceId' => $data['invoice_id']
            );

            $params = array(
                'Parameters' => $searchParams
            );

            $result = $service->GetInvoiceDocument($params);
            $file = $result->GetInvoiceDocumentResult;
        }
        catch ( SoapFault $fault )
        {
            $this->error = 'Exception: ' . $fault->getMessage();
        }
        return $file;
    }

}

?>
