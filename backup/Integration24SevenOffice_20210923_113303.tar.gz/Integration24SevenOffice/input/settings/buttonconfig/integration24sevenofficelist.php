<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:integration24sevenoffice:0:0:Integration24SevenOffice:¤Sync invoices:{$formText_SyncInvoices_module}:SyncInvoice:integration24sevenoffice:0:0:Integration24SevenOffice:¤Sync customer:{$formText_SyncCustomer_module}:SyncCustomer:integration24sevenoffice:0:0:Integration24SevenOffice:¤";
?>