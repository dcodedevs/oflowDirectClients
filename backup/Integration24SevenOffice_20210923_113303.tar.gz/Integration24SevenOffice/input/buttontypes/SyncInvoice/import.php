<?php

// error_reporting(E_ALL);
// ini_set("display_errors", 1);
	ini_set('max_execution_time', 120);

	// Ownercompany list
	$sql = "SELECT * FROM ownercompany";
	$o_query = $o_main->db->query($sql);
	$ownercompany_list = $o_query && $o_query->num_rows() ? $o_query->result_array() : array();

	if(isset($_POST['migrateData'])) {
		if($_POST['invoiceFrom'] != "" && $_POST['invoiceTo'] != ""){
	        $hook_file = __DIR__ . '/../../../hooks/sync_customer_and_invoice.php';
	        if (file_exists($hook_file)) {
	            require_once $hook_file;
	            if (is_callable($run_hook)) {
					$s_sql = "SELECT * FROM invoice WHERE id >= ? AND id <= ?";
					$o_query = $o_main->db->query($s_sql, array($_POST['invoiceFrom'], $_POST['invoiceTo']));
					$invoices = $o_query ? $o_query->result_array() : array();
					foreach($invoices as $invoice){
						if($invoice['external_invoice_nr'] > 0) {
							$hook_params = array(
			                    'invoice_id' => $invoice['id']
			                );
			                $hook_result = $run_hook($hook_params);
						}
						if(isset($hook_result['invoice_sync_result']['SaveInvoicesResult']['InvoiceOrder']['APIException']) || !isset($hook_result['invoice_sync_result']['SaveInvoicesResult']['InvoiceOrder']['InvoiceId'])) {
							break;
						}

					}
	            }
				unset($run_hook);
	        }
		}
	}
?>
<div>
	<form name="importData" method="post" enctype="multipart/form-data"  action="" >
		<div class="formRow submitRow">
			<?php echo $formText_InvoiceNumberFrom_output;?>
			<input type="text" name="invoiceFrom" value=""/><br/>
			<?php echo $formText_InvoiceNumberTo_output;?>
			<input type="text" name="invoiceTo" value=""/><br/>

			<input type="submit" name="migrateData" value="Sync invoices">

		</div>
	</form>
</div>
