<?php
/**
 *
 * @author Mikael Peigney
 */

namespace Mika56\SPFCheck\Exception;


class DNSLookupException extends \Exception
{

}