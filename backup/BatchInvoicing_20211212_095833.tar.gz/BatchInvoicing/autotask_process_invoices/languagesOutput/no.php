<?php
$formText_MissingFilesToAttachToInvoice="Mangler filer som vedlegg til faktura";
$formText_InvoiceMissingExternalInvoiceNr="Fakturaen mangler fakturanummer";
$formText_IntegrationSyncingFailed="Integrasjon synkronisering feilet";
$formText_InvoiceMissingKidNumber="Faktura mangler kidnummer";
$formText_ErrorCreatingPdf="En feil oppstod ved opprettelse av Pdf";
$formText_MissingEhfConfigurationForVat_Output="Mva koden mangler konfigurering for Ehf";
$formText_EhfInvoiceFileValidationFailed_Output="Ehf faktura validering feilet";
$formText_MoreInfo_Output="Mer info";
$formText_NotDelivered_Output="Ikke levert";
$formText_InvoiceNumber_Output="Fakturanr";
$formText_InvalidEmailSpecified_Output="Ugyldig epostadresse er spesifisert";
$formText_InvoiceHasNotBeSentByEmailToCustomer_Output="Faktura ble ikke sendt med epost";
$formText_of_Output="av";
$formText_EmailAddressesIsInvalidForCustomer_Output="Epostadressen er ugyldig";
$formText_InvoicesForPrint_output="Fakturaer som må printes";
$formText_Hi_output="Hei";
$formText_YouCanDownloadInvoicesForPrintFromBatchinvoicingModule_output="Fakturaer som skal printes ligger klare for nedlasting i batchfakturering modulen";
$formText_ClickHereToOpen_output="Klikk her for å åpne";
$formText_ErrorSendingEmail_output="En feil oppstod ved sending av epost";
$formText_InvalidEmail_output="Ugyldig e-postadresse";
$formText_AutoTaskCannotBeFound_Output="Autotask ble ikke funnet";
?>