<?php
$formText_MissingFilesToAttachToInvoice="Missing files to attach to invoice";
$formText_InvoiceMissingExternalInvoiceNr="Invoice missing external invoice nr";
$formText_IntegrationSyncingFailed="Integration syncing failed";
$formText_InvoiceMissingKidNumber="Invoice missing kid number";
$formText_ErrorCreatingPdf="Error creating pdf";
$formText_MissingEhfConfigurationForVat_Output="Missing ehf configuration for vat";
$formText_EhfInvoiceFileValidationFailed_Output="Ehf invoice file validation failed";
$formText_MoreInfo_Output="More info";
$formText_NotDelivered_Output="Not delivered";
$formText_InvoiceNumber_Output="Invoice number";
$formText_InvalidEmailSpecified_Output="Invalid email specified";
$formText_InvoiceHasNotBeSentByEmailToCustomer_Output="Invoice has not be sent by email to customer";
$formText_of_Output="Of";
$formText_EmailAddressesIsInvalidForCustomer_Output="Email addresses is invalid for customer";
$formText_InvoicesForPrint_output="Invoices for print";
$formText_Hi_output="Hi";
$formText_YouCanDownloadInvoicesForPrintFromBatchinvoicingModule_output="You can download invoices for print from batchinvoicing module";
$formText_ClickHereToOpen_output="Click here to open";
$formText_ErrorSendingEmail_output="Error sending email";
$formText_InvalidEmail_output="Invalid email";
$formText_AutoTaskCannotBeFound_Output="Auto task cannot be found";
?>