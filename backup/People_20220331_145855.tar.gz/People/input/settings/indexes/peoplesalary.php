<?php
$sys_table_indexes = array('peopleId:key:peoplesalary:peopleId');
?>