<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'name' => 1,
  'peopleId' => 1,
  'dateFrom' => 1,
  'stdOrIndividualRate' => 1,
  'standardWageRateId' => 1,
  'rate' => 1,
  'individualRateSalaryCode' => 1,
  'hourlyRate' => 1,
  'peoplesalary_group_id' => 1,
);
?>