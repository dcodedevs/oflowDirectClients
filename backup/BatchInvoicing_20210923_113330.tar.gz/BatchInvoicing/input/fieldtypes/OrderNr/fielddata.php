<?php
$thisFieldType = 60;
$thisDatabaseField = "INT";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is order number where automatically is filled with maximum number + 1 from existing content of module, when new content is added. For existing content it stays same.");
?>