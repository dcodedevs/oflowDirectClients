<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:batch_invoicing_accountconfig:0:0:BatchInvoicing:¤";
?>