<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  0 => 
  array (
    'sys_name' => $formText_DetailpageSections_settingBlocks,
    'sys_childs' => 
    array (
      'activateAddressSection' => 1,
      'activateHourlyBudgetSection' => 1,
      'activateSalarySection' => 1,
      'activateCommentsSection' => 1,
      'activateWorkIdCardSection' => 1,
      'activateBankaccountSection' => 1,
      'activateDependantSection' => 1,
      'activateFilesSection' => 1,
      'filter_by_subscription' => 1,
      'specified_subscription_type_ids' => 1,
      'show_only_persons_marked_to_show_in_intranet' => 1,
      'filter_in_owncompany_tab' => 1,
    ),
    'sys_collapse' => '1',
  ),
  1 => 
  array (
    'sys_name' => $formText_TabsAndFilters_settingBlocks,
    'sys_childs' => 
    array (
      'hide_people_tab' => 1,
      'hide_other_users_tab' => 1,
      'hide_deleted_people_tab' => 1,
      'hide_department_tab' => 1,
      'hide_access_groups_tab' => 1,
      'activate_group_tab' => 1,
      'activate_companies_tab' => 1,
      'activate_people_owncompany_tab' => 1,
      'activate_persons_tab' => 1,
    ),
    'sys_collapse' => '1',
  ),
  'activateEmailSignature' => 1,
  'activateEmployers' => 1,
  'deactivate_update_top_image' => 1,
  'activateMobileVerification' => 1,
  2 => 
  array (
    'sys_name' => $formText_Invitation_settingBlocks,
    'sys_childs' => 
    array (
      'invitation_setting' => 1,
      'invitation_config' => 1,
      'invitation_select_access' => 1,
      'invitation_accesslevel' => 1,
      'invitation_groupID' => 1,
      'invitation_contentIdField' => 1,
      'invitation_moduleName' => 1,
    ),
    'sys_collapse' => '1',
  ),
  'activate_seniority_and_salary_listview' => 1,
);
?>