<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:people_sync_other_accounts:0:0:People:¤";
?>