<?php
$sys_table_indexes = array('signant_idx:key:people_files:signant_id');
?>