<?php
$accessElementAllow_AddEditDeletePeople_name="Legge til ansatte samt se og redigere alt på alle ansatte";
$accessElementAllow_AddEditDeletePeople_description="";
$accessElementAllow_EditPersonNumber_name="Redigere personnr";
$accessElementAllow_EditPersonNumber_description="";
$accessElementAllow_GiveRemoveAccessPeople_name="Gi og fjerne tilgang for ansatte";
$accessElementAllow_GiveRemoveAccessPeople_description="";
$accessElementAllow_SendFilesToSignant_name="Sende filer til signant";
$accessElementAllow_SendFilesToSignant_description="";
$accessElementAllow_ChangeOtherProfilePicture_name="Endre profilbilde  på ansatte";
$accessElementAllow_ChangeOtherProfilePicture_description="Dette fungerer bare inntil det er gitt tilgang til personen. Etter det har den ansatte selv tatt over ansvaret for sin profil og må redigere den selv";
$accessElementAllow_ViewDepartments_name="Se avdelinger";
$accessElementAllow_ViewDepartments_description="";
$accessElementAllow_ExportPeople_name="Eksportere personer";
$accessElementAllow_ExportPeople_description="";
$accessElementAllow_ReadAllTagsAndGroups_name="Les alle tagger og grupper";
$accessElementAllow_ReadAllTagsAndGroups_description="";
?>