<?php
$accessElementAllow_AddEditDeletePeople_description="Add edit delete people";
$accessElementAllow_EditPersonNumber_description="Edit person number";
$accessElementAllow_GiveRemoveAccessPeople_description="Give remove access people";
$accessElementAllow_SendFilesToSignant_description="Send files to signant";
$accessElementAllow_ChangeOtherProfilePicture_description="Change other profile picture";
$accessElementAllow_ViewDepartments_description="View departments";
$accessElementAllow_ExportPeople_description="Export people";
$accessElementAllow_ReadAllTagsAndGroups_description="Read all tags and groups";
?>