<?php
$sys_table_indexes = array('relation:key:sys_modulemenuusers:username,set_id');
?>