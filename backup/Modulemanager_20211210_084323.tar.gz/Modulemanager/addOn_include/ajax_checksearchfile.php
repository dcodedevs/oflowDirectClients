<?php

echo file_get_contents(dirname(__FILE__)."/../../../uploads/modulesearch.txt");

?>