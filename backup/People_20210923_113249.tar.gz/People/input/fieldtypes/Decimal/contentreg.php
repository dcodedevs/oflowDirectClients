<?php
$fields[$fieldPos][6][$this->langfields[$a]] = str_replace(array(' ',','),array('','.'),$_POST[$fieldName]);
?>