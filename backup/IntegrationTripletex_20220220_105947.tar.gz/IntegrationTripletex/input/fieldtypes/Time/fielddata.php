<?php
$thisFieldType = 2;
$thisDatabaseField = "TIME";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is time field in format HH:MM:SS.");
?>