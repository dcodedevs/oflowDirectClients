<?php
$fields[$fieldPos][6][$this->langfields[$a]] = $_POST['usernamelogg'];
?>