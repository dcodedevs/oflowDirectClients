<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:people_stdmembersystem_basisconfig:0:0:People:¤";
?>