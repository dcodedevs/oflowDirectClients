<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:people_accountconfig:0:0:People:¤";
?>