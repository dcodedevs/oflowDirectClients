<?php
$fields[$fieldPos][6][$this->langfields[$a]] = intval($_POST[$fieldName]);
?>