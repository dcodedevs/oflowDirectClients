<?php
$updatedSuccessfully = 0;
$adjustPricePercent = str_replace(",", ".", $_POST['adjustPrice']);

$subscriptions = $_POST['customer'];
if($adjustPricePercent != 0) {
    foreach($subscriptions as $subscription) {
       $subscriptionLines = array();
        $s_sql_select = "SELECT sl.* FROM subscriptionline sl";
    	$s_sql_join = " ";
    	$s_sql_where = " WHERE sl.subscribtionId = ".$subscription;
    	$s_sql_group = "";

    	$s_sql = $s_sql_select.$s_sql_join.$s_sql_where.$s_sql_group;
    	$o_query = $o_main->db->query($s_sql);
    	if($o_query && $o_query->num_rows()>0){
    		$subscriptionLines = $o_query->result_array();
    	}
        $lineUpdated = 0;
        foreach($subscriptionLines as $subscriptionLine) {
            $pricePerPiece = $subscriptionLine['pricePerPiece'];
            $newPricePerPiece = number_format($pricePerPiece * (1+$adjustPricePercent/100), 2,".", "");
            if($_POST['round_prices']){
                $newPricePerPiece = round($newPricePerPiece);
            }
            $s_sql = "UPDATE subscriptionline SET pricePerPiece = ?, previous_adjustment_price = ?, previous_adjustment_date = NOW()  WHERE id = ?";
            $o_query = $o_main->db->query($s_sql, array($newPricePerPiece,$pricePerPiece, $subscriptionLine['id']));
            if($o_query) {
                $lineUpdated++;
            }
        }
        if(count($subscriptionLines) == $lineUpdated){
            $updatedSuccessfully++;
        } else {
            $fw_error_msg[] = $formText_ErrorUpdatingSubscription_output." ".$subscription;
        }
    }
    echo $updatedSuccessfully;
} else {
    $fw_error_msg[] = $formText_MissingAdjustPercent_output;
}
?>
