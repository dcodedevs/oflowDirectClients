<?php
$thisFieldType = 0;
$thisDatabaseField = "YEAR";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is dropdown with next year and 8 years back displayed.");
?>