<?php
$sys_table_indexes = array('relation_idx:key:sys_content_history:content_id,content_table');
?>