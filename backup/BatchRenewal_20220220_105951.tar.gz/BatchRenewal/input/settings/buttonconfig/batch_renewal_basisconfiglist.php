<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:batch_renewal_basisconfig:0:0:BatchRenewal:¤";
?>