<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'activateCheckForProjectNr' => 1,
  'activateCheckForDepartmentCode' => 1,
  0 => 
  array (
    'sys_name' => $formText_GetProjectCodeFromSubscription_settingBlocks,
    'sys_childs' => 
    array (
      'activateGetProjectcodeFromSubscription' => 1,
      'makeProjectcodeFromSubscriptionMandatory' => 1,
      'tablenameOnConnecttable' => 1,
      'fieldInConnecttableForSubscriptionId' => 1,
      'fieldInConnecttableForConnectedRecordId' => 1,
      'connectedRecordTableName' => 1,
      'connectedRecordConnectionFieldname' => 1,
      'tablenameToGetProjectcodeFrom' => 1,
      'fieldnameToGetProjectcodeFrom' => 1,
    ),
    'sys_collapse' => '1',
  ),
);
?>