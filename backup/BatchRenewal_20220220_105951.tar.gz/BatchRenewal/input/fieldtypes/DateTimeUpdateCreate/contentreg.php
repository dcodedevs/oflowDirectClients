<?php
$fields[$fieldPos][6][$this->langfields[$a]] = date('Y')."-".date('m')."-".date('d')." ".date('H').":".date('i').":".date('s');
?>