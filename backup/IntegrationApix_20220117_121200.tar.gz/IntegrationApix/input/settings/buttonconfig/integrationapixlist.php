<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:integrationapix:0:0:IntegrationApix:¤test send:{$formText_TestSend_module}:SendPrint:integrationapix:0:0:IntegrationApix:¤";
?>