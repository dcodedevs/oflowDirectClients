<?php
$formText_TestLanguageVariable_Output="Test language variable";
?>