<?php
/*
 * Version 8.01
*/
use PHPMailer\PHPMailer\PHPMailer;
class c_auto_task
{
	private $o_main;
	private $s_error_email_sender = "noreply@getynet.com";
	private $s_webmaster_email = "agris@dcode.no";
	private $v_alert_email = array("agris@dcode.no", "sindre@dcode.no", "agris.liepins@gmail.com");
	private $s_mailserver = "mail.dcode.no";
	private $s_mailserver_port = 25;
	
	public function __construct()
	{
		if(!class_exists('PHPMailer'))
		{
			require_once("Exception.php");
			require_once("PHPMailer.php");
			require_once("SMTP.php");
		}
		
		define('BASEPATH', realpath(__DIR__.'/../../../').'/');
		require_once(BASEPATH.'elementsGlobal/cMain.php');
		$this->o_main = $o_main;
	}
	
	public function lock()
	{
		if(is_file(__DIR__."/_job.lock"))
		{
			$v_lock = json_decode(file_get_contents(__DIR__."/_job.lock"), true);
			if($v_lock['time'] != "")
			{
				//send email with notification about too long running process (3600 sec -> 1 hour)
				if((time() - strtotime($v_lock['time']))>3600 && !isset($v_lock['alert_sent']))
				{
					$err_mail = new PHPMailer();
					$err_mail->CharSet	= 'UTF-8';
					$err_mail->Host		= $this->s_mailserver;
					$err_mail->Port		= $this->s_mailserver_port;
					$err_mail->IsSMTP(true);
					$err_mail->SetFrom($this->s_error_email_sender);
					foreach($this->v_alert_email as $s_email) $err_mail->AddAddress($s_email);
					$err_mail->Subject  = "ALERT - Cronjob running too long";
					$err_mail->Body		= "Lock info: ".var_export($v_lock,true);
					$err_mail->WordWrap = 150;
					$err_mail->Send();
					
					$v_lock['alert_sent'] = date('Y-m-d H:i',time());
					file_put_contents(__DIR__."/_job.lock",json_encode($v_lock));
				}
			}
			return false;
		}
		
		$v_lock = array();
		$v_lock['time'] = date('Y-m-d H:i',time());
		file_put_contents(__DIR__."/_job.lock",json_encode($v_lock));
		
		return true;
	}
	
	public function unlock()
	{
		unlink(__DIR__."/_job.lock");
		
		if(is_file(__DIR__."/_job.lock"))
		{
			$err_mail = new PHPMailer();
			$err_mail->CharSet	= 'UTF-8';
			$err_mail->Host		= $this->s_mailserver;
			$err_mail->Port		= $this->s_mailserver_port;
			$err_mail->IsSMTP(true);
			$err_mail->SetFrom($this->s_error_email_sender);
			foreach($this->v_alert_email as $s_email) $err_mail->AddAddress($s_email);
			$err_mail->Subject  = "ALERT - Cronjob running too long";
			$err_mail->Body		= "Lock file was not deleted";
			$err_mail->WordWrap = 150;
			$err_mail->Send();
		}
	}
	
	public function run()
	{
		$o_main = $this->o_main;
		$s_sql = "SELECT * FROM auto_task WHERE next_run <= NOW() ORDER BY id";
		$o_query = $o_main->db->query($s_sql);
		if($o_query && $o_query->num_rows()>0)
		foreach($o_query->result_array() as $v_row)
		{
			$b_run = TRUE;
			// Check if task is running longer than 12 hours. If yes then assume it is hanged
			$o_find = $o_main->db->query("SELECT id FROM auto_task_log WHERE auto_task_id = '".$o_main->db->escape_str($v_row['id'])."' AND status = 0 AND started > DATE_SUB(NOW(), INTERVAL -12 HOUR) ORDER BY started DESC");
			if($o_find && $o_find->num_rows()>0)
			{
				$b_run = FALSE;
			}
			
			if($b_run && is_file(BASEPATH.$v_row['script_path']))
			{
				$b_auto_task_fail = FALSE;
				$s_auto_task_message = '';
				$o_main->db->query("INSERT INTO auto_task_log SET auto_task_id = '".$o_main->db->escape_str($v_row['id'])."', status = 0, started = NOW()");
				$l_auto_task_log_id = $o_main->db->insert_id();
				include(BASEPATH.$v_row['script_path']);
				
				$o_main->db->query("UPDATE auto_task_log SET finished = NOW(), status = '".$o_main->db->escape_str($b_auto_task_fail ? 2 : 1)."', message = '".$o_main->db->escape_str($s_auto_task_message)."' WHERE id = '".$o_main->db->escape_str($l_auto_task_log_id)."'");
			}
		}
	}
}

$o_auto_task = new c_auto_task();
$o_auto_task->run();