<?php
$prerelations = array("id¤AutoTask¤auto_task_log¤auto_task_id¤1¤¤¤¤¤{$formText_Log_Relation}¤100¤¤¤¤¤");
?>