<?php
$sys_table_indexes = array('relation_idx:key:auto_task_log:auto_task_id');
?>