<?php
$formText_InvoiceIds_output="";
$formText_InvoiceNumbers_output="";
$formText_ThereAreInvoicesReadyForExport_AutoTask="";
$formText_AutoTaskCannotBeFound_Output="";
?>