<?php
$formText_PleaseSetRoundingAccountInSettings_output="Konto for øresavrundinger må defineres i innstillinger modulen";
$formText_Cancel_Output="Avbryt";
$formText_Export_output="Eksporter fakturaer";
?>