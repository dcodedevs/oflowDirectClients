<?php
$formText_PleaseSetRoundingAccountInSettings_output="Please set rounding account in settings";
$formText_Cancel_Output="Cancel";
$formText_Export_output="Export";
?>