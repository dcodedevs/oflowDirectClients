<?php
$sys_table_indexes = array('relation_idx:key:invoice_send_log:invoice_id');
?>