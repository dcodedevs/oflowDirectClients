<?php
$sys_table_indexes = array('kidNumber:key:invoice:kidNumber', 'invoiceDate:key:invoice:invoiceDate', 'dueDate:key:invoice:dueDate');
?>