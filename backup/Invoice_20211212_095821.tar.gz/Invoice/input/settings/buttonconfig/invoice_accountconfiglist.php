<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:invoice_accountconfig:0:0:Invoice:¤";
?>