<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:invoicereport_accountconfig:0:0:InvoiceReport:¤";
?>