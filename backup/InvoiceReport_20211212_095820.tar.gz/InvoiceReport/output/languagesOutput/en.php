<?php
$formText_DateFrom_Output="Date from";
$formText_DateTo_Output="Date to";
$formText_Filter_Output="Filter";
$formText_ArticleNumber_Output="Article number";
$formText_ArticleName_Output="Article name";
$formText_Amount_Output="Amount";
$formText_InputDates_Output="Input dates";
?>