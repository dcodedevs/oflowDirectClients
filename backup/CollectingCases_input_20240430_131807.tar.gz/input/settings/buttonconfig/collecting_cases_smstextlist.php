<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:collecting_cases_smstext:0:0:CollectingCases:¤";
?>