<?php
$prebuttonconfig = "Detect duplicate fees:{$formText_DetectDuplicateFees_module}:DetectDuplicateFees:collecting_cases:0:0:CollectingCases:¤";
?>