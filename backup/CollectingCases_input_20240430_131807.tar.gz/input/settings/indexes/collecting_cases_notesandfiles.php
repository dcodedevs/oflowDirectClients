<?php
$sys_table_indexes = array('collecting_case_id:key:collecting_cases_notesandfiles:collecting_case_id');
?>