<?php
$sys_table_indexes = array('collecting_case_id:key:collecting_cases_objection:collecting_case_id', 'objection_closed_date:key:collecting_cases_objection:objection_closed_date');
?>