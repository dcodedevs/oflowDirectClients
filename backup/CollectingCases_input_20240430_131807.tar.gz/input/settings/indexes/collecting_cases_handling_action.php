<?php
$sys_table_indexes = array('collecting_case_id:key:collecting_cases_handling_action:collecting_case_id', 'step_action_id:key:collecting_cases_handling_action:collecting_cases_process_steps_action_id');
?>