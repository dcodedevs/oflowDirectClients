<?php
$thisFieldType = 0;
$thisDatabaseField = "CHAR(20)";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is dropdown of Countries which takes values from GetynetDB - Country list. It saves down uppercase country short code, like \"NO\" or \"FR\".");
?>