<?php
$prerelations = array("id¤Article¤articlepricematrixlines¤articlePriceMatrixId¤1¤¤¤¤¤{$formText_Lines_Relation}¤¤¤¤");
?>