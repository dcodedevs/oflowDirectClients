<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:article_accountconfig:0:0:Article:¤";
?>