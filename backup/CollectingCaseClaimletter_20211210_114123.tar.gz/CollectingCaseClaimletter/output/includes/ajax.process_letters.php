<?php
if(!function_exists("generateRandomString")){
	function generateRandomString($length = 8) {
	    $characters = '0123456789abcdefghijklmnopqrs092u3tuvwxyzaskdhfhf9882323ABCDEFGHIJKLMNksadf9044OPQRSTUVWXYZ';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}
}

$s_sql = "SELECT * FROM collecting_cases_claim_letter WHERE content_status < 2 AND (sending_status is null OR sending_status = 0 OR sending_status = 2)";
$o_query = $o_main->db->query($s_sql);
$cases = $o_query ? $o_query->result_array() : array();
$casesToGenerate = $_POST['casesToGenerate'];

if(count($cases) > 0){
	$created_letters = 0;
	foreach($cases as $created_letter)
	{
		if(in_array($created_letter['id'], $casesToGenerate)) {
			$s_sql = "UPDATE collecting_cases_claim_letter SET updated = NOW(), sending_status = -1 WHERE id = '".$o_main->db->escape_str($created_letter['id'])."'";
			$o_query = $o_main->db->query($s_sql);

			$sendEmail = false;
			$s_sql = "SELECT * FROM collecting_cases WHERE id = ?";
			$o_query = $o_main->db->query($s_sql, array($created_letter['case_id']));
			$case = $o_query ? $o_query->row_array() : array();

			$s_sql = "SELECT creditor.*, customer.* FROM customer LEFT JOIN creditor ON creditor.customer_id = customer.id  WHERE creditor.id = ?";
			$o_query = $o_main->db->query($s_sql, array($case['creditor_id']));
			$creditor = ($o_query ? $o_query->row_array() : array());

			$s_sql = "SELECT * FROM customer WHERE customer.id = ?";
			$o_query = $o_main->db->query($s_sql, array($case['debitor_id']));
			$debitor = ($o_query ? $o_query->row_array() : array());

			if($created_letter['sending_action'] == 2){
				if($debitor && $debitor['invoiceEmail'] != "" && $creditor) {
					$sendEmail = true;
				}
			}
			if($sendEmail) {
				$s_sql = "select * from sys_emailserverconfig order by default_server desc";
				$o_query = $o_main->db->query($s_sql);
				$v_email_server_config = $o_query ? $o_query->row_array() : array();

				$s_sql = "INSERT INTO sys_emailsend (id, created, createdBy, `type`, send_on, sender, sender_email, subscriberlist_id, unsubscriberlist_id, content_id, content_table, content_module_id, sending_limit, subject, text, batch_id) VALUES (NULL, NOW(), ?, 2, NOW(), '', ?, 0, 0, ?, 'collecting_cases_claim_letter', '', 0, ?, ?, ?);";
				$o_main->db->query($s_sql, array($variables->loggID, $v_settings['invoiceFromEmail'], $created_letter['id'], $s_email_subject, $s_email_body, $batch_id));
				$l_emailsend_id = $o_main->db->insert_id();
				// $emailsArray = array($customer['invoiceEmail']);
				$emailsArray = array("byamba@dcode.no");
				foreach($emailsArray as $invoiceEmail)
				{
					// Trim U+00A0 (0xc2 0xa0) NO-BREAK SPACE
					//$invoiceEmail = trim($invoiceEmail,chr(0xC2).chr(0xA0));
					// Trim rest spaces and new lines
					//$invoiceEmail = trim($invoiceEmail);
					if(filter_var($invoiceEmail, FILTER_VALIDATE_EMAIL))
					{
						$mail = new PHPMailer;
						$mail->CharSet	= 'UTF-8';
						$mail->IsSMTP(true);
						$mail->isHTML(true);
						if($v_email_server_config['host'] != "")
						{
							$mail->Host	= $v_email_server_config['host'];
							if($v_email_server_config['port'] != "") $mail->Port = $v_email_server_config['port'];

							if($v_email_server_config['username'] != "" and $v_email_server_config['password'] != "")
							{
								$mail->SMTPAuth	= true;
								$mail->Username	= $v_email_server_config['username'];
								$mail->Password	= $v_email_server_config['password'];

							}
						} else {
							$mail->Host = "mail.dcode.no";
						}
						$mail->From		= $creditor['sender_email'];
						$mail->FromName	= $creditor['sender_name'];
						$mail->Subject	= $s_email_subject;
						$mail->Body		= $s_email_body;
						$mail->AddAddress($invoiceEmail);
						$mail->AddAttachment(__DIR__."/../../../../".$letter['pdf']);
						$s_sql = "INSERT INTO sys_emailsendto (id, emailsend_id, receiver, receiver_email, `status`, status_message, perform_time, perform_count) VALUES (NULL, ?, ?, ?, 1, '', NOW(), 1);";
						$o_main->db->query($s_sql, array($l_emailsend_id, $customer['name']." ".$customer['middlename']." ".$customer['lastname'], $invoiceEmail));
						$l_emailsendto_id = $o_main->db->insert_id();

						if($mail->Send())
						{
							$emails_sent++;
							$s_sql = "UPDATE collecting_cases_claim_letter SET performed_date = NOW(), performed_action = 1, sending_status = 1 WHERE id = '".$o_main->db->escape_str($created_letter['id'])."'";
				    		$o_query = $o_main->db->query($s_sql);
						}
					} else {
					}

				}
			} else {
				$l_send_status = 0;

				$sender_id = $creditor['id'];
				$sender_name = $creditor['name'];
				if($creditor['middlename'] != ""){
					$sender_name .= " ".$creditor['middlename'];
				}
				if($creditor['lastname'] != ""){
					$sender_name .= " ".$creditor['lastname'];
				}
				$sender_address = $creditor['paStreet']." ";
				$sender_address2 = $creditor['paStreet2']." ";
				$sender_city = $creditor['paCity']." ";
				$sender_postal = $creditor['paPostalNumber']." ";
				$sender_country = "NO";

				$receiver_id = $debitor['id'];
				$receiver_name = $debitor['name'];
				if($debitor['middlename'] != ""){
					$receiver_name .= " ".$debitor['middlename'];
				}
				if($debitor['lastname'] != ""){
					$receiver_name .= " ".$debitor['lastname'];
				}
				$receiver_address = $debitor['paStreet']." ";
				$receiver_address2 = $debitor['paStreet2']." ";
				$receiver_city = $debitor['paCity']." ";
				$receiver_postal = $debitor['paPostalNumber']." ";
				$receiver_country = "NO";

				$xml = new DOMDocument("1.0", "UTF-8");
				$xml_letter = $xml->createElement("Letter");
				$xml_letter->setAttribute( "Version", "1.0" );
				$xml_DocumentID = $xml->createElement("DocumentID", $case['id']);
				$xml_SenderPartyDetails = $xml->createElement("SenderPartyDetails");
				$xml_SenderPartyIdentifier = $xml->createElement("SenderPartyIdentifier", $sender_id);
				$xml_SenderOrganisationName = $xml->createElement("SenderOrganisationName", $sender_name);
				$xml_SenderOrganisationName2 = $xml->createElement("SenderOrganisationName", $sender_name2);
				$xml_SenderPostalAddressDetails = $xml->createElement("SenderPostalAddressDetails");
				$xml_SenderStreetName = $xml->createElement("SenderStreetName", $sender_address);
				$xml_SenderStreetName2 = $xml->createElement("SenderStreetName", $sender_address2);
				$xml_SenderTownName = $xml->createElement("SenderTownName", $sender_city);
				$xml_SenderPostCodeIdentifier = $xml->createElement("SenderPostCodeIdentifier", $sender_postal);
				$xml_CountryCode = $xml->createElement("CountryCode", $sender_country);


				$xml_SenderPostalAddressDetails->appendChild( $xml_SenderStreetName );
				$xml_SenderPostalAddressDetails->appendChild( $xml_SenderStreetName2 );
				$xml_SenderPostalAddressDetails->appendChild( $xml_SenderTownName );
				$xml_SenderPostalAddressDetails->appendChild( $xml_SenderPostCodeIdentifier );
				$xml_SenderPostalAddressDetails->appendChild( $xml_CountryCode );

				$xml_SenderPartyDetails->appendChild( $xml_SenderPartyIdentifier );
				$xml_SenderPartyDetails->appendChild( $xml_SenderOrganisationName );
				$xml_SenderPartyDetails->appendChild( $xml_SenderOrganisationName2 );
				$xml_SenderPartyDetails->appendChild( $xml_SenderPostalAddressDetails );

				$xml_DeliveryPartyDetails = $xml->createElement("DeliveryPartyDetails");

				$xml_DeliveryStreetName = $xml->createElement("DeliveryStreetName", $receiver_address);
				$xml_DeliveryStreetName2 = $xml->createElement("DeliveryStreetName", $receiver_address2);
				$xml_DeliveryTownName = $xml->createElement("DeliveryTownName", $receiver_city);
				$xml_DeliveryPostCodeIdentifier = $xml->createElement("DeliveryPostCodeIdentifier", $receiver_postal);
				$xml_CountryCode = $xml->createElement("CountryCode", $receiver_country);

				$xml_DeliveryPostalAddressDetails = $xml->createElement("DeliveryPostalAddressDetails");
				$xml_DeliveryPostalAddressDetails->appendChild( $xml_DeliveryStreetName );
				$xml_DeliveryPostalAddressDetails->appendChild( $xml_DeliveryStreetName2 );
				$xml_DeliveryPostalAddressDetails->appendChild( $xml_DeliveryTownName );
				$xml_DeliveryPostalAddressDetails->appendChild( $xml_DeliveryPostCodeIdentifier );
				$xml_DeliveryPostalAddressDetails->appendChild( $xml_CountryCode );

				$xml_DeliveryPartyIdentifier = $xml->createElement("DeliveryPartyIdentifier", $receiver_id);
				$xml_DeliveryOrganisationName = $xml->createElement("DeliveryOrganisationName", $receiver_name);
				$xml_DeliveryOrganisationName2 = $xml->createElement("DeliveryOrganisationName", $receiver_name2);

				$xml_DeliveryPartyDetails->appendChild( $xml_DeliveryPartyIdentifier );
				$xml_DeliveryPartyDetails->appendChild( $xml_DeliveryOrganisationName );
				$xml_DeliveryPartyDetails->appendChild( $xml_DeliveryOrganisationName2 );
				$xml_DeliveryPartyDetails->appendChild( $xml_DeliveryPostalAddressDetails );

				$pdf_url_text = basename($created_letter['pdf']);
				$xml_InvoiceUrlNameText = $xml->createElement("InvoiceUrlNameText", "APIX_PDFFILE");
				$xml_InvoiceUrlText = $xml->createElement("InvoiceUrlText", "file://".$pdf_url_text);

				$xml_letter->appendChild( $xml_DocumentID );
				$xml_letter->appendChild( $xml_SenderPartyDetails );
				$xml_letter->appendChild( $xml_DeliveryPartyDetails );
				$xml_letter->appendChild( $xml_InvoiceUrlNameText );
				$xml_letter->appendChild( $xml_InvoiceUrlText );
				$xml->appendChild( $xml_letter );

				$s_filename_xml = 'uploads/'.$formText_Claimletter_output.'_'.$case['id'].'_'.$created_letter['action_id'].'.xsd';
				$xml->save(ACCOUNT_PATH.'/'.$s_filename_xml);

				$zip = new ZipArchive();

				$DelFilePath=$formText_Claimletter_output.'_'.$case['id'].'_'.$created_letter['action_id'].'.zip';

				if(file_exists(ACCOUNT_PATH."/uploads/".$DelFilePath)) {
					unlink (ACCOUNT_PATH."/uploads/".$DelFilePath);
				}
				if ($zip->open(ACCOUNT_PATH."/uploads/".$DelFilePath, ZIPARCHIVE::CREATE) != TRUE) {
					die ("Could not open archive");
				}
				$zip->addFile(ACCOUNT_PATH."/uploads/".$formText_Claimletter_output.'_'.$case['id'].'_'.$created_letter['action_id'].'.xsd',$formText_Claimletter_output.'_'.$case['id'].'_'.$created_letter['action_id'].'xsd');
				$zip->addFile(ACCOUNT_PATH."/uploads/".$pdf_url_text,$pdf_url_text);
				// close and save archive
				$zip->close();
				$sending_result = array();
				var_dump(ACCOUNT_PATH."/uploads/".$DelFilePath);
				if(file_exists(ACCOUNT_PATH."/uploads/".$DelFilePath)) {
					$hook_file = __DIR__ . '/../../../IntegrationApix/hooks/send_print_file.php';
			        if (file_exists($hook_file)) {
			            require $hook_file;
			            if (is_callable($run_hook)) {
							$hook_params = array(
			                    'ownercompany_id' => 1,
								'zip_file_path' => ACCOUNT_PATH."/uploads/".$DelFilePath,
								'zip_file_name' => $DelFilePath
			                );
			                $sending_result = $run_hook($hook_params);
							if($sending_result['Response']['Status'] == 'OK'){
								$l_send_status = 1;
							}
			            }
						unset($run_hook);
			        } else {
						$sending_result = array("Integration not found");
					}
				} else {
					$sending_result = array("Zip file not found");
				}
				if($l_send_status == 1){
					$s_sql = "UPDATE collecting_cases_claim_letter SET performed_date = NOW(), performed_action = 0, sending_status = 1 WHERE id = '".$o_main->db->escape_str($created_letter['id'])."'";
					$o_query = $o_main->db->query($s_sql);
				} else {
					$s_sql = "UPDATE collecting_cases_claim_letter SET sending_status = 2, sending_error_log = '".$o_main->db->escape_str(json_encode($sending_result))."' WHERE id = '".$o_main->db->escape_str($created_letter['id'])."'";
					$o_query = $o_main->db->query($s_sql);
				}
			}
		}
	}
}
if($created_letters > 0){
	$fw_return_data = array(
		'status' => 1,
		'batch_id' => $batch_id,
	);
} else {
	$fw_error_msg[] = $formText_NoPdfCreated_output;
}
