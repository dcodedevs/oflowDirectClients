<?php
require_once(__DIR__."/../../../../fw/account_fw/includes/fn_fw_api_call.php");
$list_filter = $_GET['list_filter'] ? ($_GET['list_filter']) : 'all';

?>
<?php
if(isset($_GET['list_filter'])) { $filter = $_GET['list_filter']; } else { $filter = "not_printed"; }


?>
<div class="output-filter">
    <ul>
        <li class="item<?php echo ($list_filter == 'all' ? ' active':'');?>">
            <a class="topFilterlink" data-listfilter="all" href="<?php echo $_SERVER['PHP_SELF']."?pageID=".$_GET['pageID']."&accountname=".$_GET['accountname']."&companyID=".$_GET['companyID']."&caID=".$_GET['caID']."&module=".$module."&folderfile=output&folder=output&list_filter=all"; ?>">
                <span class="link_wrapper">
                    <span class="count"><?php echo $all_count; ?></span>
                    <?php echo $formText_All_output;?>
                </span>
            </a>
        </li>
        <li class="item<?php echo ($list_filter == 'not_processed' ? ' active':'');?>">
            <a class="topFilterlink" data-listfilter="not_processed" href="<?php echo $_SERVER['PHP_SELF']."?pageID=".$_GET['pageID']."&accountname=".$_GET['accountname']."&companyID=".$_GET['companyID']."&caID=".$_GET['caID']."&module=".$module."&folderfile=output&folder=output&list_filter=not_processed"; ?>">
                <span class="link_wrapper">
                    <span class="count"><?php echo $not_processed_count; ?></span>
                    <?php echo $formText_NotProcessed_output;?>
                </span>
            </a>
        </li>
        <li class="item<?php echo ($list_filter == 'processed' ? ' active':'');?>">
            <a class="topFilterlink" data-listfilter="processed" href="<?php echo $_SERVER['PHP_SELF']."?pageID=".$_GET['pageID']."&accountname=".$_GET['accountname']."&companyID=".$_GET['companyID']."&caID=".$_GET['caID']."&module=".$module."&folderfile=output&folder=output&list_filter=processed"; ?>">
                <span class="link_wrapper">
                    <span class="count"><?php echo $processed_count; ?></span>
                    <?php echo $formText_Processed_output;?>
                </span>
            </a>
        </li>
        <li class="item<?php echo ($list_filter == 'failed' ? ' active':'');?>">
            <a class="topFilterlink" data-listfilter="failed" href="<?php echo $_SERVER['PHP_SELF']."?pageID=".$_GET['pageID']."&accountname=".$_GET['accountname']."&companyID=".$_GET['companyID']."&caID=".$_GET['caID']."&module=".$module."&folderfile=output&folder=output&list_filter=failed"; ?>">
                <span class="link_wrapper">
                    <span class="count"><?php echo $failed_count; ?></span>
                    <?php echo $formText_Failed_output;?>
                </span>
            </a>
        </li>
    </ul>
</div>
<div class="launchPdfGenerate"><?php echo $formText_LaunchLetterProcess_output; ?> <span class="selected_letters">0</span></div>
<div class="clear"></div>
<script type="text/javascript">
$(document).ready(function(){
    $(".customerIdSelector").on('change', function(e) {
        var data = {
            list_filter: '<?php echo $list_filter;?>',
            customer_filter:$(".customerId").val(),
            search_filter: $('.searchFilter').val()
        };
        loadView('list', data);
    });
    // Filter by building
    $('.filterDepartment').on('change', function(e) {
        var data = {
            list_filter: '<?php echo $list_filter;?>',
            customer_filter:$(".customerId").val(),
            search_filter: $('.searchFilter').val()
        };
        loadView('list', data);
    });

    // Filter by customer name
    $('.searchFilterForm').on('submit', function(e) {
        e.preventDefault();
        var data = {
            list_filter: '<?php echo $list_filter;?>',
            customer_filter:$(".customerId").val(),
            search_filter: $('.searchFilter').val(),
        };
        loadView('list', data);
    });
    $(".resetSelection").on('click', function(e) {
        e.preventDefault();
        var data = {
            list_filter: '<?php echo $list_filter;?>',
            customer_filter:$(".customerId").val()
        };
        loadView('list', data);
    });
})
</script>
