<?php
$run_hook = function($data) {
    global $o_main;
    global $variables;

    // Params
    $transaction_id = $data['transaction_id'];
    $amount = $data['amount'];
    $text = $data['text'];
    $accountNo = $data['accountNo'];
    $dueDate = $data['dueDate'];

    $s_sql = "SELECT * FROM creditor_transactions WHERE id = ?";
    $o_query = $o_main->db->query($s_sql, array($transaction_id));
    $transaction = ($o_query ? $o_query->row_array() : array());

    $sql = "SELECT * FROM creditor WHERE id = ?";
    $o_query = $o_main->db->query($sql, array($transaction['creditor_id']));
    $creditorData = $o_query ? $o_query->row_array() : array();
    // Return object
    $return = array();
    $return['result'] = 0;
    if($creditorData){
        require_once __DIR__ . '/../internal_api/load.php';
        $api = new Integration24SevenOffice(array(
            'identityId' => $creditorData['entity_id'],
            'creditorId' => $creditorData['id'],
            'o_main' => $o_main
        ));

        $search_data = array(
            'transaction_guid'=>$transaction['transaction_id'],
            'amount'=>$amount,
            'text'=>$text,
            'accountNo'=>$accountNo,
            'customerId'=>$transaction['external_customer_id'],
            'date'=>date("c"),
            'dueDate'=>date("c", strtotime($dueDate)),
            'type' => $data['type'],
            'close'=>$data['close'],
            'invoice_nr'=>$transaction['invoice_nr'],
            'kid_number'=>$transaction['kid_number']
        );
        $customer_info = $api->insert_transactions($search_data);
        if($customer_info['result']){
            $return['result'] = 1;
        } else {
            $return['error'] = $customer_info['error'];
        }
    }
    return $return;
}

?>
