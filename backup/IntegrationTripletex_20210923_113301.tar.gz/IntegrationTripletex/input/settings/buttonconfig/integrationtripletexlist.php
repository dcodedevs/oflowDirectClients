<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:integrationtripletex:0:0:IntegrationTripletex:¤Sync all customers:{$formText_SyncAllCustomers_module}:SyncAllCustomersToTripletex:integrationtripletex:0:0:IntegrationTripletex:¤Sync all projects:{$formText_SyncAllProjects_module}:SyncAllProjectsToTripletex:integrationtripletex:0:0:IntegrationTripletex:¤";
?>