<?php
$thisFieldType = 1;
$thisDatabaseField = "LONGTEXT";
$thisShowOnList = 1;
$thisExtraFieldInfo = "";
$thisAboutInfo = str_replace(array(PHP_EOL,"\t"), array('<br />','&nbsp;&nbsp;'),
"This field is textarea field, where text appears in multiple lines and there is possible to change style of text, also insert resources inside the text. Also it is possible to see and edit HTML code of text.

Options in Extra value, separated by <b>::</b>
\t- <b>enter_br</b> - place BR code when press ENTER instead of paragraph tag.");
?>