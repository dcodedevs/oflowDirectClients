<?php
$sys_table_indexes = array('collecting_cases_process_id:key:collecting_cases_process_steps:collecting_cases_process_id', 'sortnr:key:collecting_cases_process_steps:sortnr');
?>