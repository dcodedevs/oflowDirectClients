<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'sentTime' => 1,
  'invoiceIdFrom' => 1,
  'invoiceIdTo' => 1,
  'invoiceNrFrom' => 1,
  'invoiceNrTo' => 1,
  'ownerCompanyId' => 1,
  'file' => 1,
);
?>