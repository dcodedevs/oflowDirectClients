<?php
$formText_InvoiceIds_output="FakturaSystemId";
$formText_InvoiceNumbers_output="Fakturanummer";
$formText_ThereAreInvoicesReadyForExport_AutoTask="Det finnes fakturaer klare for eksport";
$formText_AutoTaskCannotBeFound_Output="Autotask ble ikke funnet";
?>