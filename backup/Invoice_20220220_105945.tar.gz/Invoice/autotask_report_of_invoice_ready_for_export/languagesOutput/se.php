<?php
$formText_InvoiceIds_output="FakturaSystemId";
$formText_InvoiceNumbers_output="Fakturanummer ";
$formText_ThereAreInvoicesReadyForExport_AutoTask="Det finns fakturor klara för export ";
$formText_AutoTaskCannotBeFound_Output="Autotask hittades inte";
?>