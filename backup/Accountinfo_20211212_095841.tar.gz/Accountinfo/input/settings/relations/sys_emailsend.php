<?php
$prerelations = array('id¤Accountinfo¤sys_emailsendto¤emailsend_id¤1¤¤¤subject¤');
?>