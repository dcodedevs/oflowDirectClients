<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'name' => 1,
  'host' => 1,
  'port' => 1,
  'username' => 1,
  'password' => 1,
  'default_server' => 1,
  'content_status' => 1,
);
?>