<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_local_languagevariable_basisconfig:0:0:Accountinfo:¤";
?>