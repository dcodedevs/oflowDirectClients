<?php
$prebuttonconfig = "New:{$formText_New_module}:AddItem:sys_emailserverconfig:0:0:Accountinfo:¤";
?>