<?php
$prebuttonconfig = "New:{$formText_New_module}:AddItem:sys_smsserviceconfig:0:0:Accountinfo:¤";
?>