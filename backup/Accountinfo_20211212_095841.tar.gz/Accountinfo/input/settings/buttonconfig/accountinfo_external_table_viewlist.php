<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_external_table_view:0:0:Accountinfo:¤";
?>