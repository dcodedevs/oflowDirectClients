<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_invitation_basisconfig:0:0:Accountinfo:¤";
?>