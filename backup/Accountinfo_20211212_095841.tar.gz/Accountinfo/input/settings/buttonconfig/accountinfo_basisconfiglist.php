<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_basisconfig:0:0:Accountinfo:¤";
?>