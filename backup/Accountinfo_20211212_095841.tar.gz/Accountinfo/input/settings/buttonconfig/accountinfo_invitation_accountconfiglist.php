<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_invitation_accountconfig:0:0:Accountinfo:¤";
?>