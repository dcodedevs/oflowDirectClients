<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_emailsender_accountconfig:0:0:Accountinfo:¤";
?>