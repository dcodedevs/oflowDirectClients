<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:accountinfo_smssender_accountconfig:0:0:Accountinfo:¤";
?>