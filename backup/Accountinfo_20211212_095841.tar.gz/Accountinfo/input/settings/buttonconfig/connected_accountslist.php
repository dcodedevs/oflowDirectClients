<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:connected_accounts:0:0:Accountinfo:¤";
?>