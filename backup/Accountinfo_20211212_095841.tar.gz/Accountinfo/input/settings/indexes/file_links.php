<?php
$sys_table_indexes = array('link_key:key:file_links:link_key');
?>