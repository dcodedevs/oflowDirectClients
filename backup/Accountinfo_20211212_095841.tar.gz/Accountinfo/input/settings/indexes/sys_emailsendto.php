<?php
$sys_table_indexes = array('relation:key:sys_emailsendto:emailsend_id', 'receiver:key:sys_emailsendto:receiver_email', 'unique_receiver:unique:sys_emailsendto:emailsend_id,receiver_email');
?>