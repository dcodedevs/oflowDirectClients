<?php
$sys_table_indexes = array('relation:key:sys_smssend:content_id,content_table,content_module_id', 'send_on:key:sys_smssend:send_on');
?>