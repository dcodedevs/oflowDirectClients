<?php
$sys_table_indexes = array('key_used:key:file_links_log:key_used');
?>