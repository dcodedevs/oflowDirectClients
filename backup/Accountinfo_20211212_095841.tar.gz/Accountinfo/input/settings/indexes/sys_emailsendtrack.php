<?php
$sys_table_indexes = array('track_id:key:sys_emailsendtrack:track_id,track_action');
?>