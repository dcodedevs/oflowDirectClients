<?php
$sys_table_indexes = array('find_idx:key:accountinfo_mobile_auth:user_id,expire,object');
?>