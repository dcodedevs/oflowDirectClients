<?php
$sys_table_indexes = array('content:key:sys_emailsend:content_id,content_table,content_module_id', 'send_on:key:sys_emailsend:send_on');
?>