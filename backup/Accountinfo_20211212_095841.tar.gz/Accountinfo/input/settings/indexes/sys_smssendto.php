<?php
$sys_table_indexes = array('relation:key:sys_smssendto:smssend_id', 'receiver:key:sys_smssendto:receiver_mobile');
?>