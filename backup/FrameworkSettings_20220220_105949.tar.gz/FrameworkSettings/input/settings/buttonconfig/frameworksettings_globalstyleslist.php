<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:frameworksettings_globalstyles:0:0:FrameworkSettings:¤";
?>