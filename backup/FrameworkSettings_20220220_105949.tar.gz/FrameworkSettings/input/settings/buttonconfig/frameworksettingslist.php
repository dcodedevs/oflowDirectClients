<?php
$prebuttonconfig = "Add:{$formText_Add_module}:AddItem:frameworksettings:0:0:FrameworkSettings¤";
?>