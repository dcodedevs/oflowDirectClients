<?php
$formText_InvoiceIds_output="Invoice ids";
$formText_InvoiceNumbers_output="Invoice numbers";
$formText_ThereAreInvoicesReadyForExport_AutoTask="There are invoices ready for export";
$formText_AutoTaskCannotBeFound_Output="Auto task cannot be found";
?>