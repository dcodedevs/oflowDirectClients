<?php
$v_auto_task_config = array(
	'runtime_y' => null,
	'runtime_m' => null,
	'runtime_d' => null,
	'runtime_h' => '07',
	'runtime_i' => '00',
	'repeat_minutes' => 1440, // 1 - one minute, 60 - one hour, 1440 - one day
	'parameters' => array(
		'time' => array(
			'input' => 1,
			'value' => "07:00",
		)
	),
);
