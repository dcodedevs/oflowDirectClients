<?php
$preblocks = array (
  'id' => 1,
  'moduleID' => 1,
  'createdBy' => 1,
  'created' => 1,
  'updatedBy' => 1,
  'updated' => 1,
  'origId' => 1,
  'sortnr' => 1,
  'content_status' => 1,
  'activate_global_export' => 1,
  'invoices_per_page' => 1,
  'export_integration' => 1,
  'show_accounting_info' => 1,
);
?>